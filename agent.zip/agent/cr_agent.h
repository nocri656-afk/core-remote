/*
 * cr_agent.h — Loop principal del agente CoreRemote
 *
 * El agente:
 *  1. Inicializa la sesión (conecta al server.js local)
 *  2. Entra en el loop interactivo leyendo líneas de stdin
 *  3. Parsea cada línea con cr_cmd_parse
 *  4. Despacha con cr_cmd_dispatch → POST /api/cmd → server.js
 *  5. Imprime la respuesta en stdout
 *  6. Maneja comandos internos: cr.help, salir, clear, estado
 */
#ifndef CR_AGENT_H
#define CR_AGENT_H

#include "cr_types.h"

/*
 * Inicializa la sesión del agente.
 *  host : servidor al que conectar (NULL = 127.0.0.1)
 *  port : puerto (0 = 3001)
 * Devuelve CR_OK o código de error.
 */
cr_result_t cr_agent_init(cr_session_t *sess,
                          const char   *host,
                          int           port);

/*
 * Comprueba si el server.js responde (GET /).
 * Devuelve CR_OK si está activo.
 */
cr_result_t cr_agent_ping(cr_session_t *sess);

/*
 * Imprime el banner de bienvenida en stdout.
 */
void cr_agent_banner(const cr_session_t *sess);

/*
 * Imprime el estado de la sesión actual.
 */
void cr_agent_status(const cr_session_t *sess);

/*
 * Imprime la ayuda de comandos internos del agente.
 */
void cr_agent_help(void);

/*
 * Loop principal: lee stdin, parsea y despacha hasta que
 * el usuario escribe "salir" o llega EOF.
 * Devuelve CR_OK al salir limpiamente.
 */
cr_result_t cr_agent_run(cr_session_t *sess);

#endif /* CR_AGENT_H */
