/*
 * main.c — Entry point del agente CoreRemote
 *
 * Uso:
 *   ./cr_agent                        # conecta a 127.0.0.1:3001
 *   ./cr_agent 192.168.1.10           # host personalizado, puerto 3001
 *   ./cr_agent 192.168.1.10 8080      # host y puerto personalizados
 *
 * Compilar con build.sh
 */

#include "cr_agent.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
    const char *host = NULL;
    int         port = 0;

    /* Argumentos opcionales: [host] [port] */
    if (argc >= 2) host = argv[1];
    if (argc >= 3) port = atoi(argv[2]);

    /* Validar puerto si se pasó */
    if (argc >= 3 && (port <= 0 || port > 65535)) {
        fprintf(stderr,
                "CoreRemote Agent: puerto inválido '%s'.\n"
                "Uso: %s [host] [puerto]\n",
                argv[2], argv[0]);
        return EXIT_FAILURE;
    }

    /* Inicializar sesión */
    cr_session_t sess;
    cr_result_t  r = cr_agent_init(&sess, host, port);
    if (r != CR_OK) {
        fprintf(stderr, "CoreRemote Agent: error inicializando sesión (%d).\n", r);
        return EXIT_FAILURE;
    }

    /* Loop principal — bloquea hasta que el usuario escribe "salir" */
    r = cr_agent_run(&sess);

    return (r == CR_OK) ? EXIT_SUCCESS : EXIT_FAILURE;
}
