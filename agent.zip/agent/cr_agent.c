/*
 * cr_agent.c -- Loop principal del agente CoreRemote
 */

#include "cr_agent.h"
#include "cr_cmd.h"
#include "cr_net.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

/* Colores ANSI solo en no-Windows */
#ifdef _WIN32
#  define COL_RESET ""
#  define COL_GREEN ""
#  define COL_CYAN  ""
#  define COL_RED   ""
#  define COL_DIM   ""
#  define COL_BOLD  ""
#else
#  define COL_RESET "\033[0m"
#  define COL_GREEN "\033[0;32m"
#  define COL_CYAN  "\033[0;36m"
#  define COL_RED   "\033[0;31m"
#  define COL_DIM   "\033[2m"
#  define COL_BOLD  "\033[1m"
#endif

#define SEP "--------------------------------------------------------\n"

/* ---------------------------------------------------------------
 * cr_agent_init
 * --------------------------------------------------------------- */
cr_result_t cr_agent_init(cr_session_t *sess,
                          const char   *host,
                          int           port)
{
    if (!sess) return CR_ERR_ARGS;
    memset(sess, 0, sizeof(*sess));

    strncpy(sess->host,
            host ? host : CR_SERVER_HOST,
            sizeof(sess->host) - 1);
    sess->port = port > 0 ? port : CR_SERVER_PORT;
    strncpy(sess->agent_version, CR_AGENT_VERSION,
            sizeof(sess->agent_version) - 1);
    strncpy(sess->cwd, ".", sizeof(sess->cwd) - 1);

    snprintf(sess->session_id, sizeof(sess->session_id),
             "cr-%lx", (unsigned long)time(NULL));

    return CR_OK;
}

/* ---------------------------------------------------------------
 * cr_agent_ping
 * --------------------------------------------------------------- */
cr_result_t cr_agent_ping(cr_session_t *sess)
{
    cr_response_t resp;
    cr_result_t r = cr_net_request(sess->host, sess->port,
                                   "/", NULL, &resp);
    if (r != CR_OK) {
        sess->connected = 0;
        return r;
    }
    sess->connected = (resp.status >= 200 && resp.status < 500) ? 1 : 0;
    return sess->connected ? CR_OK : CR_ERR_CONNECT;
}

/* ---------------------------------------------------------------
 * cr_agent_banner  (ASCII puro, sin Unicode)
 * --------------------------------------------------------------- */
void cr_agent_banner(const cr_session_t *sess)
{
    printf("\n");
    printf("  +----------------------------------------------------+\n");
    printf("  |                                                    |\n");
    printf("  |    ____                 ____                 _     |\n");
    printf("  |   / ___|___  _ __ ___  |  _ \\ ___ _ __ ___ | |_   |\n");
    printf("  |  | |   / _ \\| '__/ _ \\ | |_) / _ \\ '_ ` _ \\| __|  |\n");
    printf("  |  | |__| (_) | | |  __/ |  _ <  __/ | | | | | |_   |\n");
    printf("  |   \\____\\___/|_|  \\___| |_| \\_\\___|_| |_| |_|\\__|  |\n");
    printf("  |                                                    |\n");
    printf("  |  Native Agent v%-33s   |\n", sess->agent_version);
    printf("  +----------------------------------------------------+\n");
    printf("\n");
    printf("  Host    : %s:%d\n",   sess->host, sess->port);
    printf("  Session : %s\n",      sess->session_id);
    printf("  Status  : connected\n");
    printf("  Type      cr.help   to list all commands\n");
    printf("  Type      estado    to show session status\n");
    printf("  Type      salir     to quit\n");
    printf("\n");
}

/* ---------------------------------------------------------------
 * cr_agent_status
 * --------------------------------------------------------------- */
void cr_agent_status(const cr_session_t *sess)
{
    printf(SEP);
    printf("  CoreRemote Agent -- Session Status\n");
    printf(SEP);
    printf("  Version   : %s\n",  sess->agent_version);
    printf("  Server    : %s:%d\n", sess->host, sess->port);
    printf("  Session   : %s\n",  sess->session_id);
    printf("  Connected : %s\n",  sess->connected ? "yes" : "no");
    printf("  Directory : %s\n",  sess->cwd[0] ? sess->cwd : ".");
    printf(SEP);
}

/* ---------------------------------------------------------------
 * cr_agent_help
 * --------------------------------------------------------------- */
void cr_agent_help(void)
{
    printf(SEP);
    printf("  CoreRemote Agent -- Internal Commands\n");
    printf(SEP);
    printf("  %-30s %s\n", "cr.help",  "List all CoreRemote commands");
    printf("  %-30s %s\n", "estado",   "Show session status");
    printf("  %-30s %s\n", "clear",    "Clear the screen");
    printf("  %-30s %s\n", "salir",    "Quit the agent");
    printf(SEP);
    printf("  Remote command examples:\n");
    printf("    cr.directorio.ver\n");
    printf("    cr.proceso.lista\n");
    printf("    cr.archivo.leer ruta=\"C:\\Temp\\log.txt\" lineas=50\n");
    printf("    cr.directorio.ir ruta=\"C:\\Users\"\n");
    printf(SEP);
}

/* ---------------------------------------------------------------
 * Helpers internos
 * --------------------------------------------------------------- */
static char *trim(char *s)
{
    while (isspace((unsigned char)*s)) s++;
    if (*s == '\0') return s;
    char *end = s + strlen(s) - 1;
    while (end > s && isspace((unsigned char)*end)) *end-- = '\0';
    return s;
}

static void clear_screen(void)
{
#ifdef _WIN32
    system("cls");
#else
    printf("\033[H\033[2J");
    fflush(stdout);
#endif
}

static void print_prompt(const cr_session_t *sess)
{
    printf("cr[%s]> ", sess->connected ? "ok" : "!!");
    fflush(stdout);
}

/* ---------------------------------------------------------------
 * cr_agent_run -- Loop principal
 * --------------------------------------------------------------- */
cr_result_t cr_agent_run(cr_session_t *sess)
{
    char line[CR_MAX_CMD_LEN];

    printf("  Checking connection to %s:%d ...\n",
           sess->host, sess->port);

    if (cr_agent_ping(sess) == CR_OK) {
        printf("  Server reachable.\n\n");
    } else {
        printf("  WARNING: server not responding.\n"
               "  Make sure 'node server.js' is running.\n\n");
    }

    cr_agent_banner(sess);

    while (1) {
        print_prompt(sess);

        if (!fgets(line, sizeof(line), stdin)) {
            printf("\n");
            break;
        }

        char *cmd_str = trim(line);
        if (cmd_str[0] == '\0') continue;

        /* -- Comandos internos ---------------------------------- */
        if (strcmp(cmd_str, "salir") == 0 ||
            strcmp(cmd_str, "exit")  == 0 ||
            strcmp(cmd_str, "quit")  == 0) {
            printf("  Closing CoreRemote Agent...\n");
            break;
        }

        if (strcmp(cmd_str, "clear") == 0 ||
            strcmp(cmd_str, "cls")   == 0) {
            clear_screen();
            continue;
        }

        if (strcmp(cmd_str, "estado") == 0 ||
            strcmp(cmd_str, "status") == 0) {
            cr_agent_ping(sess);
            cr_agent_status(sess);
            continue;
        }

        if (strcmp(cmd_str, "cr.help") == 0 ||
            strcmp(cmd_str, "ayuda")   == 0 ||
            strcmp(cmd_str, "help")    == 0) {
            cr_agent_help();
            continue;
        }

        /* -- Parsear y despachar al server.js ------------------ */
        cr_cmd_t cmd;
        cr_result_t r = cr_cmd_parse(cmd_str, &cmd);

        if (r != CR_OK) {
            printf("  Parse error: %d\n", r);
            continue;
        }

        r = cr_cmd_dispatch(&cmd, sess);

        if (r == CR_ERR_CONNECT || r == CR_ERR_TIMEOUT) {
            sess->connected = 0;
            printf("  No connection to server. "
                   "Check that node server.js is running.\n");
        } else if (r == CR_ERR_CMD_UNKNOWN) {
            printf("  Unknown command: %s\n"
                   "  Type cr.help to see available commands.\n",
                   cmd.verb);
        } else if (r != CR_OK) {
            printf("  Command error: %d\n", r);
        }
    }

    return CR_OK;
}
