/*
 * cr_net.c — Implementación de conexión TCP/HTTP al server.js de CoreRemote
 *
 * Usa sockets POSIX estándar (compatible Linux / macOS).
 * Para Windows compilar con -lws2_32 y activar Winsock (ver build.sh).
 */

#include "cr_net.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

/* ── Portabilidad Windows / POSIX ───────────────────────────── */
#ifdef _WIN32
#  include <winsock2.h>
#  include <ws2tcpip.h>
#  pragma comment(lib, "ws2_32.lib")
   typedef SOCKET cr_sock_t;
#  define CR_INVALID_SOCK  INVALID_SOCKET
#  define CR_SOCK_ERR      SOCKET_ERROR
#  define cr_sock_close(s) closesocket(s)
#  define CR_EINTR         WSAEINTR
static int winsock_init_done = 0;
static void cr_winsock_init(void) {
    if (!winsock_init_done) {
        WSADATA wd;
        WSAStartup(MAKEWORD(2,2), &wd);
        winsock_init_done = 1;
    }
}
#else
#  include <unistd.h>
#  include <sys/types.h>
#  include <sys/socket.h>
#  include <netinet/in.h>
#  include <arpa/inet.h>
#  include <netdb.h>
#  include <sys/time.h>
   typedef int cr_sock_t;
#  define CR_INVALID_SOCK  (-1)
#  define CR_SOCK_ERR      (-1)
#  define cr_sock_close(s) close(s)
#  define CR_EINTR         EINTR
#  define cr_winsock_init()  /* noop */
#endif

/* ─────────────────────────────────────────────────────────────
 * cr_net_connect
 * ───────────────────────────────────────────────────────────── */
int cr_net_connect(const char *host, int port)
{
    cr_winsock_init();

    struct addrinfo hints, *res, *rp;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family   = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;

    char port_str[16];
    snprintf(port_str, sizeof(port_str), "%d", port);

    if (getaddrinfo(host, port_str, &hints, &res) != 0) {
        fprintf(stderr, "[cr_net] getaddrinfo failed: %s\n", host);
        return -1;
    }

    cr_sock_t fd = CR_INVALID_SOCK;
    for (rp = res; rp != NULL; rp = rp->ai_next) {
        fd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
        if (fd == CR_INVALID_SOCK) continue;

        /* timeout de conexión */
#ifdef _WIN32
        DWORD tv = CR_CONNECT_TIMEOUT_SEC * 1000;
        setsockopt((SOCKET)fd, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv, sizeof(tv));
        setsockopt((SOCKET)fd, SOL_SOCKET, SO_SNDTIMEO, (const char*)&tv, sizeof(tv));
#else
        struct timeval tv;
        tv.tv_sec  = CR_CONNECT_TIMEOUT_SEC;
        tv.tv_usec = 0;
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
#endif

        if (connect(fd, rp->ai_addr, (int)rp->ai_addrlen) == 0) break;

        cr_sock_close(fd);
        fd = CR_INVALID_SOCK;
    }
    freeaddrinfo(res);

    if (fd == CR_INVALID_SOCK) {
        fprintf(stderr, "[cr_net] connect failed: %s:%d\n", host, port);
        return -1;
    }

    return (int)fd;
}

/* ─────────────────────────────────────────────────────────────
 * cr_net_close
 * ───────────────────────────────────────────────────────────── */
void cr_net_close(int sockfd)
{
    if (sockfd >= 0) cr_sock_close((cr_sock_t)sockfd);
}

/* ─────────────────────────────────────────────────────────────
 * cr_net_send_all  (helper interno)
 * ───────────────────────────────────────────────────────────── */
static cr_result_t cr_net_send_all(int sockfd, const char *buf, int len)
{
    int sent = 0;
    while (sent < len) {
        int n = (int)send((cr_sock_t)sockfd, buf + sent, len - sent, 0);
        if (n <= 0) return CR_ERR_SEND;
        sent += n;
    }
    return CR_OK;
}

/* ─────────────────────────────────────────────────────────────
 * cr_net_get
 * ───────────────────────────────────────────────────────────── */
cr_result_t cr_net_get(int sockfd, const char *path, const char *host)
{
    char req[CR_MAX_CMD_LEN];
    int  len = snprintf(req, sizeof(req),
        "GET %s HTTP/1.1\r\n"
        "Host: %s\r\n"
        "Connection: close\r\n"
        "User-Agent: CoreRemote-Agent/" CR_AGENT_VERSION "\r\n"
        "\r\n",
        path, host);
    return cr_net_send_all(sockfd, req, len);
}

/* ─────────────────────────────────────────────────────────────
 * cr_net_post
 * ───────────────────────────────────────────────────────────── */
cr_result_t cr_net_post(int sockfd,
                        const char *path,
                        const char *host,
                        const char *body)
{
    int body_len = (int)strlen(body);
    char header[CR_MAX_CMD_LEN];
    int  hlen = snprintf(header, sizeof(header),
        "POST %s HTTP/1.1\r\n"
        "Host: %s\r\n"
        "Connection: close\r\n"
        "Content-Type: application/json; charset=utf-8\r\n"
        "Content-Length: %d\r\n"
        "User-Agent: CoreRemote-Agent/" CR_AGENT_VERSION "\r\n"
        "\r\n",
        path, host, body_len);

    cr_result_t r = cr_net_send_all(sockfd, header, hlen);
    if (r != CR_OK) return r;
    return cr_net_send_all(sockfd, body, body_len);
}

/* ─────────────────────────────────────────────────────────────
 * cr_net_recv
 * Lee la respuesta HTTP completa. Separa cabeceras del cuerpo.
 * ───────────────────────────────────────────────────────────── */
cr_result_t cr_net_recv(int sockfd, cr_response_t *resp)
{
    memset(resp, 0, sizeof(*resp));

    char raw[CR_MAX_RESP_LEN + 1];
    int  total = 0;

    while (total < CR_MAX_RESP_LEN) {
        int n = (int)recv((cr_sock_t)sockfd,
                          raw + total,
                          CR_MAX_RESP_LEN - total, 0);
        if (n < 0) {
            if (errno == CR_EINTR) continue;
            return CR_ERR_RECV;
        }
        if (n == 0) break;   /* servidor cerró la conexión */
        total += n;
    }
    raw[total] = '\0';

    /* Parsear código de estado  "HTTP/1.x NNN ..." */
    if (sscanf(raw, "HTTP/%*s %d", &resp->status) != 1) {
        resp->status = 0;
        return CR_ERR_PARSE;
    }

    /* Localizar inicio del cuerpo (después de \r\n\r\n) */
    const char *body_start = strstr(raw, "\r\n\r\n");
    if (body_start) {
        body_start += 4;
        resp->body_len = (int)(raw + total - body_start);
        if (resp->body_len > (int)sizeof(resp->body) - 1)
            resp->body_len = (int)sizeof(resp->body) - 1;
        memcpy(resp->body, body_start, resp->body_len);
        resp->body[resp->body_len] = '\0';
    }

    return CR_OK;
}

/* ─────────────────────────────────────────────────────────────
 * cr_net_request  — todo en uno
 * ───────────────────────────────────────────────────────────── */
cr_result_t cr_net_request(const char *host,
                           int         port,
                           const char *path,
                           const char *body,
                           cr_response_t *resp)
{
    const char *h = host ? host : CR_SERVER_HOST;
    int         p = port > 0 ? port : CR_SERVER_PORT;

    int fd = cr_net_connect(h, p);
    if (fd < 0) return CR_ERR_CONNECT;

    char host_hdr[300];
    snprintf(host_hdr, sizeof(host_hdr), "%s:%d", h, p);

    cr_result_t r;
    if (body && body[0]) {
        r = cr_net_post(fd, path, host_hdr, body);
    } else {
        r = cr_net_get(fd, path, host_hdr);
    }

    if (r == CR_OK) r = cr_net_recv(fd, resp);

    cr_net_close(fd);
    return r;
}
