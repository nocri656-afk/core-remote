#!/usr/bin/env bash
# =============================================================
# build.sh — Compilación del agente CoreRemote
# =============================================================
# Uso:
#   ./build.sh            # compilación normal
#   ./build.sh debug      # con símbolos de depuración
#   ./build.sh clean      # elimina el binario y objetos
# =============================================================

set -euo pipefail

# ── Configuración ──────────────────────────────────────────────
TARGET="cr_agent"
CC="${CC:-gcc}"
SRCS="main.c cr_net.c cr_cmd.c cr_agent.c"
CFLAGS="-std=c11 -Wall -Wextra -Wpedantic -Wshadow \
        -Wformat=2 -Wno-unused-parameter"
LDFLAGS=""
BUILD_DIR="build"

# ── Detectar plataforma ─────────────────────────────────────────
OS="$(uname -s 2>/dev/null || echo 'Windows')"

case "$OS" in
    Linux*)
        LDFLAGS="-lpthread"
        ;;
    Darwin*)
        LDFLAGS=""
        ;;
    MINGW*|MSYS*|CYGWIN*|Windows*)
        LDFLAGS="-lws2_32"
        TARGET="cr_agent.exe"
        ;;
    *)
        echo "Sistema no reconocido: $OS — usando flags POSIX por defecto."
        ;;
esac

# ── Acción: clean ──────────────────────────────────────────────
if [[ "${1:-}" == "clean" ]]; then
    echo "Limpiando artefactos..."
    rm -rf "$BUILD_DIR"
    echo "Listo."
    exit 0
fi

# ── Acción: debug ──────────────────────────────────────────────
if [[ "${1:-}" == "debug" ]]; then
    CFLAGS="$CFLAGS -g3 -O0 -DDEBUG"
    echo "Modo DEBUG activado."
else
    CFLAGS="$CFLAGS -O2 -DNDEBUG"
fi

# ── Crear directorio de salida ──────────────────────────────────
mkdir -p "$BUILD_DIR"

# ── Compilar ───────────────────────────────────────────────────
echo "Compilando agente CoreRemote..."
echo "  CC      : $CC"
echo "  CFLAGS  : $CFLAGS"
echo "  LDFLAGS : $LDFLAGS"
echo "  OUTPUT  : $BUILD_DIR/$TARGET"
echo ""

# shellcheck disable=SC2086
"$CC" $CFLAGS \
    -I. \
    $SRCS \
    -o "$BUILD_DIR/$TARGET" \
    $LDFLAGS

# ── Resultado ──────────────────────────────────────────────────
echo ""
echo "✓ Compilación exitosa → $BUILD_DIR/$TARGET"
echo ""
echo "Para ejecutar:"
echo "  1. Inicia el servidor:  node ../server.js"
echo "  2. Inicia el agente:    ./$BUILD_DIR/$TARGET"
echo "  3. Opcional con host:   ./$BUILD_DIR/$TARGET 192.168.1.10 3001"
echo ""
