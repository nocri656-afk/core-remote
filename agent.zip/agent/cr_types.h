/*
 * cr_types.h — Tipos, structs y constantes globales del agente CoreRemote
 */
#ifndef CR_TYPES_H
#define CR_TYPES_H

#include <stdint.h>
#include <stddef.h>

/* ── Versión ─────────────────────────────────────────────────── */
#define CR_AGENT_VERSION  "1.0.0"
#define CR_AGENT_NAME     "CoreRemote Agent"

/* ── Conexión por defecto al server.js local ─────────────────── */
#define CR_SERVER_HOST    "127.0.0.1"
#define CR_SERVER_PORT    3001
#define CR_CONNECT_TIMEOUT_SEC  5
#define CR_RECV_TIMEOUT_SEC     10

/* ── Límites generales ───────────────────────────────────────── */
#define CR_MAX_CMD_LEN    2048
#define CR_MAX_PATH_LEN   1024
#define CR_MAX_NAME_LEN   256
#define CR_MAX_ARGS       32
#define CR_MAX_RESP_LEN   65536   /* 64 KB máximo por respuesta */
#define CR_MAX_PAIRS      32      /* pares clave=valor por comando */

/* ── Códigos de resultado ────────────────────────────────────── */
typedef enum {
    CR_OK              =  0,
    CR_ERR_ARGS        = -1,   /* argumentos inválidos           */
    CR_ERR_CONNECT     = -2,   /* no se pudo conectar al server  */
    CR_ERR_SEND        = -3,   /* error enviando datos           */
    CR_ERR_RECV        = -4,   /* error recibiendo datos         */
    CR_ERR_TIMEOUT     = -5,   /* timeout de conexión/recepción  */
    CR_ERR_PARSE       = -6,   /* error parseando respuesta      */
    CR_ERR_CMD_UNKNOWN = -7,   /* comando no reconocido          */
    CR_ERR_SYSTEM      = -8,   /* error de sistema operativo     */
    CR_ERR_NOMEM       = -9    /* sin memoria                    */
} cr_result_t;

/* ── Par clave=valor extraído de la línea de comando ─────────── */
typedef struct {
    char key[CR_MAX_NAME_LEN];
    char value[CR_MAX_PATH_LEN];
} cr_pair_t;

/* ── Comando parseado ─────────────────────────────────────────── */
typedef struct {
    char      verb[CR_MAX_NAME_LEN];   /* ej: "cr.directorio.ver"  */
    cr_pair_t pairs[CR_MAX_PAIRS];     /* pares clave=valor        */
    int       npairs;                  /* cantidad de pares        */
    /* flags de confirmación */
    int       confirmar;               /* 1 si confirmar="SI"      */
} cr_cmd_t;

/* ── Respuesta HTTP simplificada ─────────────────────────────── */
typedef struct {
    int  status;                       /* código HTTP (200, 404…)  */
    char body[CR_MAX_RESP_LEN];        /* cuerpo de la respuesta   */
    int  body_len;
} cr_response_t;

/* ── Contexto de sesión del agente ───────────────────────────── */
typedef struct {
    char host[256];
    int  port;
    int  connected;                    /* 1 = conectado            */
    char cwd[CR_MAX_PATH_LEN];         /* directorio de trabajo    */
    char session_id[64];               /* id de sesión activa      */
    char agent_version[32];
} cr_session_t;

#endif /* CR_TYPES_H */
