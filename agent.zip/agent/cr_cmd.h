/*
 * cr_cmd.h — Parser y despachador de comandos CoreRemote
 *
 * Cubre todos los grupos del commands.dat:
 *   SESIÓN, DIRECTORIO, MARCADORES, ARCHIVOS, RUTAS Y UNIDADES,
 *   TRANSFERENCIAS, ESPACIOS DE TRABAJO, PROCESOS, VENTANAS,
 *   CONTROL COMBINADO, POSICIONES GUARDADAS, PANTALLAS, EXTENSIONES,
 *   ATAJOS RÁPIDOS
 */
#ifndef CR_CMD_H
#define CR_CMD_H

#include "cr_types.h"
#include "cr_net.h"

/* ── Parser ──────────────────────────────────────────────────────
 * Convierte la línea de texto cruda en un cr_cmd_t.
 * Soporta sintaxis:  cr.directorio.ver solo="carpetas" ocultos="SI"
 * Devuelve CR_OK o CR_ERR_PARSE / CR_ERR_ARGS.
 */
cr_result_t cr_cmd_parse(const char *line, cr_cmd_t *out);

/* ── Valor de un par por clave ───────────────────────────────────
 * Devuelve el puntero al valor o NULL si la clave no existe.
 */
const char *cr_cmd_get(const cr_cmd_t *cmd, const char *key);

/* ── Despachador principal ───────────────────────────────────────
 * Recibe el comando parseado y la sesión activa.
 * Construye el JSON, lo envía al server.js e imprime la respuesta.
 * Devuelve CR_OK o código de error.
 */
cr_result_t cr_cmd_dispatch(const cr_cmd_t   *cmd,
                             cr_session_t     *sess);

/* ── Constructores de JSON por grupo ─────────────────────────────
 * Cada función escribe el JSON en buf (tamaño buf_size).
 * Devuelve el número de bytes escritos o -1 si el buffer es pequeño.
 */

/* SESIÓN */
int cr_json_sesion         (const cr_cmd_t *c, char *buf, int sz);

/* DIRECTORIO */
int cr_json_directorio     (const cr_cmd_t *c, char *buf, int sz);

/* MARCADORES */
int cr_json_marca          (const cr_cmd_t *c, char *buf, int sz);

/* ARCHIVOS */
int cr_json_archivo        (const cr_cmd_t *c, char *buf, int sz);

/* RUTAS Y UNIDADES */
int cr_json_ruta           (const cr_cmd_t *c, char *buf, int sz);
int cr_json_unidad         (const cr_cmd_t *c, char *buf, int sz);
int cr_json_compartido     (const cr_cmd_t *c, char *buf, int sz);

/* TRANSFERENCIAS */
int cr_json_transferencia  (const cr_cmd_t *c, char *buf, int sz);

/* ESPACIOS DE TRABAJO */
int cr_json_espacio        (const cr_cmd_t *c, char *buf, int sz);

/* PROCESOS */
int cr_json_proceso        (const cr_cmd_t *c, char *buf, int sz);

/* VENTANAS */
int cr_json_ventana        (const cr_cmd_t *c, char *buf, int sz);

/* CONTROL COMBINADO */
int cr_json_control        (const cr_cmd_t *c, char *buf, int sz);

/* POSICIONES GUARDADAS */
int cr_json_posicion       (const cr_cmd_t *c, char *buf, int sz);

/* PANTALLAS */
int cr_json_pantalla       (const cr_cmd_t *c, char *buf, int sz);

/* EXTENSIONES */
int cr_json_extension      (const cr_cmd_t *c, char *buf, int sz);

#endif /* CR_CMD_H */
