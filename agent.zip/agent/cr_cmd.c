/*
 * cr_cmd.c — Parser y despachador de todos los comandos CoreRemote
 */

#include "cr_cmd.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* ═══════════════════════════════════════════════════════════════
 * Helpers internos
 * ═══════════════════════════════════════════════════════════════ */

/* Escapa comillas dobles para incluir un string en JSON */
static int json_str(char *dst, int dsz, const char *src)
{
    int n = 0;
    for (; *src && n < dsz - 2; src++) {
        if (*src == '"' || *src == '\\') dst[n++] = '\\';
        dst[n++] = *src;
    }
    dst[n] = '\0';
    return n;
}

/* snprintf seguro que devuelve bytes escritos sin contar el \0 */
#define JFMT(buf, sz, ...) snprintf(buf, sz, __VA_ARGS__)

/* Valor de par o cadena vacía si no existe */
static const char *pv(const cr_cmd_t *c, const char *key)
{
    const char *v = cr_cmd_get(c, key);
    return v ? v : "";
}

/* ═══════════════════════════════════════════════════════════════
 * cr_cmd_parse
 * Sintaxis soportada:
 *   cr.directorio.ver solo="carpetas" ocultos="SI"
 *   cr.archivo.copiar origen="C:\Temp\a.txt" destino="D:\b.txt"
 * ═══════════════════════════════════════════════════════════════ */
cr_result_t cr_cmd_parse(const char *line, cr_cmd_t *out)
{
    if (!line || !out) return CR_ERR_ARGS;
    memset(out, 0, sizeof(*out));

    /* Copiar línea para tokenizar */
    char buf[CR_MAX_CMD_LEN];
    strncpy(buf, line, CR_MAX_CMD_LEN - 1);
    buf[CR_MAX_CMD_LEN - 1] = '\0';

    /* Primer token = verbo */
    char *p = buf;
    while (isspace((unsigned char)*p)) p++;

    char *end = p;
    while (*end && !isspace((unsigned char)*end)) end++;
    int vlen = (int)(end - p);
    if (vlen <= 0 || vlen >= (int)sizeof(out->verb)) return CR_ERR_PARSE;
    memcpy(out->verb, p, vlen);
    out->verb[vlen] = '\0';

    p = end;

    /* Parsear pares  key="value"  o  key=value  (sin comillas) */
    while (*p && out->npairs < CR_MAX_PAIRS) {
        while (isspace((unsigned char)*p)) p++;
        if (!*p) break;

        /* leer key */
        char *keyst = p;
        while (*p && *p != '=' && !isspace((unsigned char)*p)) p++;
        if (*p != '=') { p++; continue; }
        int klen = (int)(p - keyst);
        if (klen <= 0 || klen >= (int)sizeof(out->pairs[0].key)) { p++; continue; }

        cr_pair_t *pair = &out->pairs[out->npairs];
        memcpy(pair->key, keyst, klen);
        pair->key[klen] = '\0';
        p++; /* saltar '=' */

        /* leer value */
        char *valst;
        int   vallen;
        if (*p == '"') {
            p++;
            valst = p;
            while (*p && *p != '"') p++;
            vallen = (int)(p - valst);
            if (*p == '"') p++;
        } else {
            valst = p;
            while (*p && !isspace((unsigned char)*p)) p++;
            vallen = (int)(p - valst);
        }
        if (vallen >= (int)sizeof(pair->value)) vallen = (int)sizeof(pair->value) - 1;
        memcpy(pair->value, valst, vallen);
        pair->value[vallen] = '\0';

        /* flag confirmar */
        if (strcmp(pair->key, "confirmar") == 0 &&
            (pair->value[0]=='S'||pair->value[0]=='s'))
            out->confirmar = 1;

        out->npairs++;
    }

    return CR_OK;
}

/* ═══════════════════════════════════════════════════════════════
 * cr_cmd_get
 * ═══════════════════════════════════════════════════════════════ */
const char *cr_cmd_get(const cr_cmd_t *cmd, const char *key)
{
    for (int i = 0; i < cmd->npairs; i++)
        if (strcmp(cmd->pairs[i].key, key) == 0)
            return cmd->pairs[i].value;
    return NULL;
}

/* ═══════════════════════════════════════════════════════════════
 * Constructores JSON — cada grupo del commands.dat
 * ═══════════════════════════════════════════════════════════════ */

/* ── SESIÓN ──────────────────────────────────────────────────── */
int cr_json_sesion(const cr_cmd_t *c, char *buf, int sz)
{
    return JFMT(buf, sz,
        "{\"cmd\":\"%s\"}",
        c->verb);
}

/* ── DIRECTORIO ──────────────────────────────────────────────── */
int cr_json_directorio(const cr_cmd_t *c, char *buf, int sz)
{
    char ruta[CR_MAX_PATH_LEN*2]   = {0};
    char origen[CR_MAX_PATH_LEN*2] = {0};
    char destino[CR_MAX_PATH_LEN*2]= {0};
    char archivo[CR_MAX_PATH_LEN*2]= {0};
    json_str(ruta,    sizeof(ruta),    pv(c,"ruta"));
    json_str(origen,  sizeof(origen),  pv(c,"origen"));
    json_str(destino, sizeof(destino), pv(c,"destino"));
    json_str(archivo, sizeof(archivo), pv(c,"archivo"));

    const char *solo     = pv(c,"solo");
    const char *ocultos  = pv(c,"ocultos");
    const char *ordenar  = pv(c,"ordenar");
    const char *padres   = pv(c,"padres");
    const char *niveles  = pv(c,"niveles");
    const char *unidad   = pv(c,"unidad");

    return JFMT(buf, sz,
        "{"
        "\"cmd\":\"%s\","
        "\"ruta\":\"%s\","
        "\"origen\":\"%s\","
        "\"destino\":\"%s\","
        "\"archivo\":\"%s\","
        "\"solo\":\"%s\","
        "\"ocultos\":\"%s\","
        "\"ordenar\":\"%s\","
        "\"padres\":\"%s\","
        "\"niveles\":\"%s\","
        "\"unidad\":\"%s\","
        "\"confirmar\":%s"
        "}",
        c->verb, ruta, origen, destino, archivo,
        solo, ocultos, ordenar, padres, niveles, unidad,
        c->confirmar ? "true" : "false");
}

/* ── MARCADORES ──────────────────────────────────────────────── */
int cr_json_marca(const cr_cmd_t *c, char *buf, int sz)
{
    char nombre[CR_MAX_NAME_LEN*2] = {0};
    char ruta[CR_MAX_PATH_LEN*2]   = {0};
    json_str(nombre, sizeof(nombre), pv(c,"nombre"));
    json_str(ruta,   sizeof(ruta),   pv(c,"ruta"));

    return JFMT(buf, sz,
        "{\"cmd\":\"%s\",\"nombre\":\"%s\",\"ruta\":\"%s\",\"confirmar\":%s}",
        c->verb, nombre, ruta, c->confirmar ? "true" : "false");
}

/* ── ARCHIVOS ────────────────────────────────────────────────── */
int cr_json_archivo(const cr_cmd_t *c, char *buf, int sz)
{
    char ruta[CR_MAX_PATH_LEN*2]   = {0};
    char origen[CR_MAX_PATH_LEN*2] = {0};
    char destino[CR_MAX_PATH_LEN*2]= {0};
    char nombre[CR_MAX_NAME_LEN*2] = {0};
    char texto[CR_MAX_PATH_LEN*2]  = {0};
    json_str(ruta,    sizeof(ruta),    pv(c,"ruta"));
    json_str(origen,  sizeof(origen),  pv(c,"origen"));
    json_str(destino, sizeof(destino), pv(c,"destino"));
    json_str(nombre,  sizeof(nombre),  pv(c,"nombre"));
    json_str(texto,   sizeof(texto),   pv(c,"texto"));

    const char *lineas = pv(c,"lineas");

    return JFMT(buf, sz,
        "{"
        "\"cmd\":\"%s\","
        "\"ruta\":\"%s\","
        "\"origen\":\"%s\","
        "\"destino\":\"%s\","
        "\"nombre\":\"%s\","
        "\"texto\":\"%s\","
        "\"lineas\":\"%s\","
        "\"confirmar\":%s"
        "}",
        c->verb, ruta, origen, destino, nombre, texto, lineas,
        c->confirmar ? "true" : "false");
}

/* ── RUTAS Y UNIDADES ────────────────────────────────────────── */
int cr_json_ruta(const cr_cmd_t *c, char *buf, int sz)
{
    char ruta[CR_MAX_PATH_LEN*2] = {0};
    char valor[CR_MAX_PATH_LEN*2]= {0};
    json_str(ruta,  sizeof(ruta),  pv(c,"ruta"));
    json_str(valor, sizeof(valor), pv(c,"valor"));

    return JFMT(buf, sz,
        "{\"cmd\":\"%s\",\"ruta\":\"%s\",\"valor\":\"%s\"}",
        c->verb, ruta, valor);
}

int cr_json_unidad(const cr_cmd_t *c, char *buf, int sz)
{
    return JFMT(buf, sz,
        "{\"cmd\":\"%s\",\"unidad\":\"%s\"}",
        c->verb, pv(c,"unidad"));
}

int cr_json_compartido(const cr_cmd_t *c, char *buf, int sz)
{
    return JFMT(buf, sz,
        "{\"cmd\":\"%s\",\"nombre\":\"%s\"}",
        c->verb, pv(c,"nombre"));
}

/* ── TRANSFERENCIAS ──────────────────────────────────────────── */
int cr_json_transferencia(const cr_cmd_t *c, char *buf, int sz)
{
    char origen[CR_MAX_PATH_LEN*2] = {0};
    char destino[CR_MAX_PATH_LEN*2]= {0};
    json_str(origen,  sizeof(origen),  pv(c,"origen"));
    json_str(destino, sizeof(destino), pv(c,"destino"));

    return JFMT(buf, sz,
        "{"
        "\"cmd\":\"%s\","
        "\"origen\":\"%s\","
        "\"destino\":\"%s\","
        "\"id\":\"%s\","
        "\"confirmar\":%s"
        "}",
        c->verb, origen, destino, pv(c,"id"),
        c->confirmar ? "true" : "false");
}

/* ── ESPACIOS DE TRABAJO ─────────────────────────────────────── */
int cr_json_espacio(const cr_cmd_t *c, char *buf, int sz)
{
    char nombre[CR_MAX_NAME_LEN*2] = {0};
    char ruta[CR_MAX_PATH_LEN*2]   = {0};
    char destino[CR_MAX_PATH_LEN*2]= {0};
    json_str(nombre,  sizeof(nombre),  pv(c,"nombre"));
    json_str(ruta,    sizeof(ruta),    pv(c,"ruta"));
    json_str(destino, sizeof(destino), pv(c,"destino"));

    return JFMT(buf, sz,
        "{"
        "\"cmd\":\"%s\","
        "\"nombre\":\"%s\","
        "\"ruta\":\"%s\","
        "\"destino\":\"%s\","
        "\"copia\":\"%s\""
        "}",
        c->verb, nombre, ruta, destino, pv(c,"copia"));
}

/* ── PROCESOS ────────────────────────────────────────────────── */
int cr_json_proceso(const cr_cmd_t *c, char *buf, int sz)
{
    char nombre[CR_MAX_NAME_LEN*2] = {0};
    json_str(nombre, sizeof(nombre), pv(c,"nombre"));

    return JFMT(buf, sz,
        "{"
        "\"cmd\":\"%s\","
        "\"pid\":\"%s\","
        "\"nombre\":\"%s\","
        "\"filtro\":\"%s\","
        "\"ventanas\":\"%s\","
        "\"ordenar\":\"%s\","
        "\"modo\":\"%s\","
        "\"nivel\":\"%s\","
        "\"confirmar\":%s"
        "}",
        c->verb,
        pv(c,"pid"), nombre,
        pv(c,"filtro"), pv(c,"ventanas"), pv(c,"ordenar"),
        pv(c,"modo"), pv(c,"nivel"),
        c->confirmar ? "true" : "false");
}

/* ── VENTANAS ────────────────────────────────────────────────── */
int cr_json_ventana(const cr_cmd_t *c, char *buf, int sz)
{
    char proceso[CR_MAX_NAME_LEN*2] = {0};
    char pantalla[CR_MAX_NAME_LEN*2]= {0};
    json_str(proceso,  sizeof(proceso),  pv(c,"proceso"));
    json_str(pantalla, sizeof(pantalla), pv(c,"pantalla"));

    return JFMT(buf, sz,
        "{"
        "\"cmd\":\"%s\","
        "\"pid\":\"%s\","
        "\"proceso\":\"%s\","
        "\"x\":\"%s\","
        "\"y\":\"%s\","
        "\"ancho\":\"%s\","
        "\"alto\":\"%s\","
        "\"pantalla\":\"%s\""
        "}",
        c->verb,
        pv(c,"pid"), proceso,
        pv(c,"x"), pv(c,"y"),
        pv(c,"ancho"), pv(c,"alto"),
        pantalla);
}

/* ── CONTROL COMBINADO ───────────────────────────────────────── */
int cr_json_control(const cr_cmd_t *c, char *buf, int sz)
{
    char nombre[CR_MAX_NAME_LEN*2] = {0};
    json_str(nombre, sizeof(nombre), pv(c,"nombre"));

    return JFMT(buf, sz,
        "{"
        "\"cmd\":\"%s\","
        "\"nombre\":\"%s\","
        "\"x\":\"%s\","
        "\"y\":\"%s\","
        "\"ancho\":\"%s\","
        "\"alto\":\"%s\","
        "\"modo\":\"%s\","
        "\"confirmar\":%s"
        "}",
        c->verb, nombre,
        pv(c,"x"), pv(c,"y"),
        pv(c,"ancho"), pv(c,"alto"),
        pv(c,"modo"),
        c->confirmar ? "true" : "false");
}

/* ── POSICIONES GUARDADAS ────────────────────────────────────── */
int cr_json_posicion(const cr_cmd_t *c, char *buf, int sz)
{
    char nombre[CR_MAX_NAME_LEN*2] = {0};
    json_str(nombre, sizeof(nombre), pv(c,"nombre"));

    return JFMT(buf, sz,
        "{"
        "\"cmd\":\"%s\","
        "\"nombre\":\"%s\","
        "\"pid\":\"%s\","
        "\"x\":\"%s\","
        "\"y\":\"%s\","
        "\"ancho\":\"%s\","
        "\"alto\":\"%s\","
        "\"confirmar\":%s"
        "}",
        c->verb, nombre,
        pv(c,"pid"),
        pv(c,"x"), pv(c,"y"),
        pv(c,"ancho"), pv(c,"alto"),
        c->confirmar ? "true" : "false");
}

/* ── PANTALLAS ───────────────────────────────────────────────── */
int cr_json_pantalla(const cr_cmd_t *c, char *buf, int sz)
{
    return JFMT(buf, sz,
        "{\"cmd\":\"%s\",\"numero\":\"%s\"}",
        c->verb, pv(c,"numero"));
}

/* ── EXTENSIONES ─────────────────────────────────────────────── */
int cr_json_extension(const cr_cmd_t *c, char *buf, int sz)
{
    char nombre[CR_MAX_NAME_LEN*2]  = {0};
    char archivo[CR_MAX_PATH_LEN*2] = {0};
    json_str(nombre,  sizeof(nombre),  pv(c,"nombre"));
    json_str(archivo, sizeof(archivo), pv(c,"archivo"));

    return JFMT(buf, sz,
        "{"
        "\"cmd\":\"%s\","
        "\"nombre\":\"%s\","
        "\"archivo\":\"%s\","
        "\"confirmar\":%s"
        "}",
        c->verb, nombre, archivo,
        c->confirmar ? "true" : "false");
}

/* ═══════════════════════════════════════════════════════════════
 * cr_cmd_dispatch
 * Selecciona el builder JSON correcto según el prefijo del verbo,
 * llama a cr_net_request y muestra la respuesta.
 * ═══════════════════════════════════════════════════════════════ */
cr_result_t cr_cmd_dispatch(const cr_cmd_t *cmd, cr_session_t *sess)
{
    char json[CR_MAX_CMD_LEN * 2];
    int  jlen = 0;

    const char *v = cmd->verb;

    /* Seleccionar builder por prefijo de namespace */
    if      (strncmp(v, "cr.sesion.",      10) == 0 ||
             strncmp(v, "cr.equipo.",      10) == 0 ||
             strncmp(v, "cr.reloj.",        9) == 0 ||
             strncmp(v, "cr.agente.",      10) == 0)
        jlen = cr_json_sesion(cmd, json, sizeof(json));

    else if (strncmp(v, "cr.directorio.", 14) == 0)
        jlen = cr_json_directorio(cmd, json, sizeof(json));

    else if (strncmp(v, "cr.marca.",       9) == 0)
        jlen = cr_json_marca(cmd, json, sizeof(json));

    else if (strncmp(v, "cr.archivo.",    11) == 0)
        jlen = cr_json_archivo(cmd, json, sizeof(json));

    else if (strncmp(v, "cr.ruta.",        8) == 0)
        jlen = cr_json_ruta(cmd, json, sizeof(json));

    else if (strncmp(v, "cr.unidad.",     10) == 0)
        jlen = cr_json_unidad(cmd, json, sizeof(json));

    else if (strncmp(v, "cr.compartido.", 14) == 0)
        jlen = cr_json_compartido(cmd, json, sizeof(json));

    else if (strncmp(v, "cr.transferencia.", 17) == 0)
        jlen = cr_json_transferencia(cmd, json, sizeof(json));

    else if (strncmp(v, "cr.espacio.",    11) == 0)
        jlen = cr_json_espacio(cmd, json, sizeof(json));

    else if (strncmp(v, "cr.proceso.",    11) == 0)
        jlen = cr_json_proceso(cmd, json, sizeof(json));

    else if (strncmp(v, "cr.ventana.",    11) == 0)
        jlen = cr_json_ventana(cmd, json, sizeof(json));

    else if (strncmp(v, "cr.control.",    11) == 0)
        jlen = cr_json_control(cmd, json, sizeof(json));

    else if (strncmp(v, "cr.posicion.",   12) == 0)
        jlen = cr_json_posicion(cmd, json, sizeof(json));

    else if (strncmp(v, "cr.pantalla.",   12) == 0)
        jlen = cr_json_pantalla(cmd, json, sizeof(json));

    else if (strncmp(v, "cr.extension.",  13) == 0)
        jlen = cr_json_extension(cmd, json, sizeof(json));

    else {
        fprintf(stderr, "[cr_cmd] comando desconocido: %s\n", v);
        return CR_ERR_CMD_UNKNOWN;
    }

    if (jlen <= 0) {
        fprintf(stderr, "[cr_cmd] error construyendo JSON para: %s\n", v);
        return CR_ERR_PARSE;
    }

    /* Enviar al server.js */
    cr_response_t resp;
    cr_result_t r = cr_net_request(
        sess->host,
        sess->port,
        "/api/cmd",
        json,
        &resp
    );

    if (r != CR_OK) {
        fprintf(stderr, "[cr_cmd] error de red: %d\n", r);
        return r;
    }

    /* Mostrar respuesta */
    printf("[%d] %s\n", resp.status, resp.body_len > 0 ? resp.body : "(sin cuerpo)");
    return CR_OK;
}
