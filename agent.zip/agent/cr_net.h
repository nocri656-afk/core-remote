/*
 * cr_net.h — Conexión TCP/HTTP al server.js local de CoreRemote
 */
#ifndef CR_NET_H
#define CR_NET_H

#include "cr_types.h"

/*
 * Abre un socket TCP hacia host:port.
 * Devuelve el file descriptor del socket, o -1 en error.
 */
int cr_net_connect(const char *host, int port);

/*
 * Cierra el socket.
 */
void cr_net_close(int sockfd);

/*
 * Envía una petición HTTP GET al server.js.
 *   sockfd  : socket ya conectado
 *   path    : ruta del recurso, ej "/api/cmd"
 *   host    : valor para la cabecera Host
 * Devuelve CR_OK o un código de error cr_result_t.
 */
cr_result_t cr_net_get(int sockfd, const char *path, const char *host);

/*
 * Envía una petición HTTP POST al server.js con body JSON.
 *   sockfd  : socket ya conectado
 *   path    : ruta del recurso, ej "/api/cmd"
 *   host    : valor para la cabecera Host
 *   body    : string JSON del cuerpo
 * Devuelve CR_OK o un código de error cr_result_t.
 */
cr_result_t cr_net_post(int sockfd,
                        const char *path,
                        const char *host,
                        const char *body);

/*
 * Lee la respuesta HTTP completa del socket y la almacena en *resp.
 * Devuelve CR_OK o un código de error cr_result_t.
 */
cr_result_t cr_net_recv(int sockfd, cr_response_t *resp);

/*
 * Función todo-en-uno: conecta, envía POST con body JSON,
 * recibe la respuesta, cierra el socket.
 * host y port se toman de la sesión si se pasan NULL/0.
 */
cr_result_t cr_net_request(const char *host,
                           int         port,
                           const char *path,
                           const char *body,
                           cr_response_t *resp);

#endif /* CR_NET_H */
