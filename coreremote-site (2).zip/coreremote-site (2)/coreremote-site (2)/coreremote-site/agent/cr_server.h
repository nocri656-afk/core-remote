/*
 * cr_server.h -- Modo servidor del agente CoreRemote
 *
 * El agente escucha en TCP 0.0.0.0:3002
 * Protocolo de mensajes (framing simple):
 *
 *   REQUEST  : [4 bytes longitud big-endian][JSON payload]
 *   RESPONSE : [4 bytes longitud big-endian][JSON payload]
 *
 * El JSON de request es el mismo formato que /api/cmd:
 *   { "cmd": "cr.directorio.ver", "ruta": "C:\\Temp" }
 *
 * El JSON de response:
 *   { "ok": true,  "data": { ... } }
 *   { "ok": false, "error": "..." }
 */
#ifndef CR_SERVER_H
#define CR_SERVER_H

#include "cr_types.h"

#define CR_AGENT_LISTEN_PORT  3002
#define CR_AGENT_BACKLOG      8
#define CR_MAX_JSON_BUF       (256 * 1024)   /* 256 KB */

/*
 * Arranca el loop de escucha TCP.
 * Bloquea hasta recibir SIGINT / error fatal.
 * sess : sesion inicializada con cr_agent_init().
 */
cr_result_t cr_server_run(cr_session_t *sess);

#endif /* CR_SERVER_H */
