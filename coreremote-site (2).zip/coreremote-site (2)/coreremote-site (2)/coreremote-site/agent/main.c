/*
 * main.c -- Entry point del agente CoreRemote
 *
 * Uso:
 *   ./cr_agent                          -> modo servidor TCP (default)
 *   ./cr_agent --interactive            -> modo stdin interactivo
 *   ./cr_agent --host 192.168.1.10      -> host de server.js
 *   ./cr_agent --port 8080              -> puerto de server.js
 */

#include "cr_agent.h"
#include "cr_server.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
    const char *host        = NULL;
    int         port        = 0;
    int         interactive = 0;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--interactive") || !strcmp(argv[i], "-i")) {
            interactive = 1;
        } else if (!strcmp(argv[i], "--host") && i+1 < argc) {
            host = argv[++i];
        } else if (!strcmp(argv[i], "--port") && i+1 < argc) {
            port = atoi(argv[++i]);
        } else if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) {
            printf("Uso: %s [--interactive] [--host HOST] [--port PORT]\n", argv[0]);
            printf("  (sin flags) : modo servidor TCP en 0.0.0.0:%d\n", CR_AGENT_LISTEN_PORT);
            printf("  --interactive : modo stdin para debug\n");
            return 0;
        }
    }

    cr_session_t sess;
    if (cr_agent_init(&sess, host, port) != CR_OK) {
        fprintf(stderr, "Error inicializando sesion.\n");
        return EXIT_FAILURE;
    }

    if (interactive) {
        /* Modo debug: loop stdin */
        return cr_agent_run(&sess) == CR_OK ? EXIT_SUCCESS : EXIT_FAILURE;
    }

    /* Modo servidor: escuchar en TCP 3002 */
    printf("\n  CoreRemote Agent v%s -- Server Mode\n", sess.agent_version);
    printf("  Session : %s\n", sess.session_id);
    printf("  Listening on 0.0.0.0:%d\n\n", CR_AGENT_LISTEN_PORT);

    return cr_server_run(&sess) == CR_OK ? EXIT_SUCCESS : EXIT_FAILURE;
}
