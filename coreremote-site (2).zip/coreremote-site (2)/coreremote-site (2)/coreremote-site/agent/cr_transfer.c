/*
 * cr_transfer.c -- Transferencia de archivos con barra de progreso
 */

#include "cr_transfer.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#ifdef _WIN32
#  include <winsock2.h>
#  include <ws2tcpip.h>
#  include <direct.h>    /* _mkdir */
   typedef SOCKET cr_sock2_t;
#  define SOCK_SEND(s,b,l) send((SOCKET)(s),(b),(l),0)
#  define SOCK_RECV(s,b,l) recv((SOCKET)(s),(b),(l),0)
#  define SOCK_CLOSE(s)    closesocket((SOCKET)(s))
#else
#  include <unistd.h>
#  include <sys/socket.h>
#  include <sys/stat.h>  /* mkdir */
   typedef int cr_sock2_t;
#  define SOCK_SEND(s,b,l) send((s),(b),(l),0)
#  define SOCK_RECV(s,b,l) recv((s),(b),(l),0)
#  define SOCK_CLOSE(s)    close(s)
#endif

#define CHUNK_SIZE  (64 * 1024)   /* 64 KB por chunk */
#define BAR_WIDTH   25

/* ---------------------------------------------------------------
 * Helpers internos
 * --------------------------------------------------------------- */

static void fmt_bytes(char *buf, int bufsz, long long bytes)
{
    if (bytes < 1024)
        snprintf(buf, bufsz, "%lld B", bytes);
    else if (bytes < 1024 * 1024)
        snprintf(buf, bufsz, "%.1f KB", (double)bytes / 1024.0);
    else if (bytes < 1024LL * 1024 * 1024)
        snprintf(buf, bufsz, "%.1f MB", (double)bytes / (1024.0 * 1024.0));
    else
        snprintf(buf, bufsz, "%.2f GB", (double)bytes / (1024.0*1024.0*1024.0));
}

/*
 * Imprime la barra de progreso en la misma linea (\r sin \n).
 * label  : "Enviando objetos  " o "Recibiendo objetos"
 * done   : bytes procesados
 * total  : bytes totales (0 = desconocido)
 * finish : 1 = imprimir \n al final
 */
static void print_bar(const char *label,
                      long long done, long long total,
                      int finish)
{
    int pct = (total > 0) ? (int)((done * 100) / total) : 0;

    /* Barra */
    int filled = (total > 0) ? (int)((done * BAR_WIDTH) / total) : 0;
    if (filled > BAR_WIDTH) filled = BAR_WIDTH;

    char bar[BAR_WIDTH + 4];
    int i;
    for (i = 0; i < filled - 1 && i < BAR_WIDTH; i++) bar[i] = '=';
    if (filled > 0 && filled <= BAR_WIDTH)             bar[i++] = '>';
    for (; i < BAR_WIDTH; i++) bar[i] = ' ';
    bar[BAR_WIDTH] = '\0';

    char sdone[32], stotal[32];
    fmt_bytes(sdone, sizeof(sdone), done);

    if (total > 0) {
        fmt_bytes(stotal, sizeof(stotal), total);
        printf("\r  %s: %3d%% [%s] %s / %s    ",
               label, pct, bar, sdone, stotal);
    } else {
        printf("\r  %s:   ?? [%s] %s         ",
               label, bar, sdone);
    }

    if (finish) printf("\n");
    fflush(stdout);
}

/* Envia todos los bytes del buffer por el socket */
static int send_all(int fd, const char *buf, int len)
{
    int sent = 0;
    while (sent < len) {
        int n = (int)SOCK_SEND(fd, buf + sent, len - sent);
        if (n <= 0) return -1;
        sent += n;
    }
    return 0;
}

/* ---------------------------------------------------------------
 * cr_transfer_send
 * POST /api/transfer/send con streaming del archivo
 * --------------------------------------------------------------- */
cr_result_t cr_transfer_send(cr_session_t *sess,
                             const char   *origen,
                             const char   *destino)
{
    /* Abrir archivo origen */
    FILE *f = fopen(origen, "rb");
    if (!f) {
        fprintf(stderr, "[transfer] No se puede abrir: %s (%s)\n",
                origen, strerror(errno));
        return CR_ERR_ARGS;
    }

    /* Obtener tamano */
    fseek(f, 0, SEEK_END);
    long long file_size = (long long)ftell(f);
    fseek(f, 0, SEEK_SET);

    /* Conectar */
    int fd = cr_net_connect(sess->host, sess->port);
    if (fd < 0) { fclose(f); return CR_ERR_CONNECT; }

    /* Construir cabeceras HTTP */
    char header[2048];
    char host_hdr[300];
    snprintf(host_hdr, sizeof(host_hdr), "%s:%d", sess->host, sess->port);

    int hlen = snprintf(header, sizeof(header),
        "POST /api/transfer/send HTTP/1.1\r\n"
        "Host: %s\r\n"
        "Connection: close\r\n"
        "Content-Type: application/octet-stream\r\n"
        "Content-Length: %lld\r\n"
        "X-CR-Origen: %s\r\n"
        "X-CR-Destino: %s\r\n"
        "User-Agent: CoreRemote-Agent/" CR_AGENT_VERSION "\r\n"
        "\r\n",
        host_hdr, file_size, origen, destino);

    if (send_all(fd, header, hlen) < 0) {
        fclose(f); cr_net_close(fd); return CR_ERR_SEND;
    }

    /* Enviar archivo en chunks con barra de progreso */
    char   chunk[CHUNK_SIZE];
    long long sent_bytes = 0;
    size_t  n;

    printf("\n");
    print_bar("Enviando objetos  ", 0, file_size, 0);

    while ((n = fread(chunk, 1, sizeof(chunk), f)) > 0) {
        if (send_all(fd, chunk, (int)n) < 0) {
            fclose(f); cr_net_close(fd);
            printf("\n");
            fprintf(stderr, "[transfer] Error enviando datos.\n");
            return CR_ERR_SEND;
        }
        sent_bytes += (long long)n;
        print_bar("Enviando objetos  ", sent_bytes, file_size, 0);
    }
    fclose(f);

    print_bar("Enviando objetos  ", sent_bytes, file_size, 1);

    /* Leer respuesta HTTP */
    cr_response_t resp;
    cr_result_t r = cr_net_recv(fd, &resp);
    cr_net_close(fd);

    if (r != CR_OK) return r;

    if (resp.status == 200) {
        printf("  Transferencia completada. %lld bytes enviados.\n", sent_bytes);
        printf("  Destino: %s\n", destino);
        return CR_OK;
    } else {
        fprintf(stderr, "[transfer] Servidor respondio %d: %s\n",
                resp.status, resp.body);
        return CR_ERR_RECV;
    }
}

/* ---------------------------------------------------------------
 * cr_transfer_recv
 * GET /api/transfer/recv?ruta=<origen>&destino=<nombre>
 * --------------------------------------------------------------- */
cr_result_t cr_transfer_recv(cr_session_t *sess,
                             const char   *origen,
                             const char   *destino)
{
    /* Construir URL con query string */
    char path[CR_MAX_PATH_LEN * 3];
    char enc_origen[CR_MAX_PATH_LEN * 2];

    /* Codificar la ruta para URL (reemplazar espacios y backslashes) */
    int ei = 0;
    for (int i = 0; origen[i] && ei < (int)sizeof(enc_origen) - 4; i++) {
        unsigned char c = (unsigned char)origen[i];
        if (c == '\\') {
            enc_origen[ei++] = '%';
            enc_origen[ei++] = '5';
            enc_origen[ei++] = 'C';
        } else if (c == ' ') {
            enc_origen[ei++] = '%';
            enc_origen[ei++] = '2';
            enc_origen[ei++] = '0';
        } else {
            enc_origen[ei++] = (char)c;
        }
    }
    enc_origen[ei] = '\0';

    snprintf(path, sizeof(path),
             "/api/transfer/recv?ruta=%s", enc_origen);

    /* Conectar */
    int fd = cr_net_connect(sess->host, sess->port);
    if (fd < 0) return CR_ERR_CONNECT;

    /* Enviar GET */
    char host_hdr[300];
    snprintf(host_hdr, sizeof(host_hdr), "%s:%d", sess->host, sess->port);
    cr_result_t r = cr_net_get(fd, path, host_hdr);
    if (r != CR_OK) { cr_net_close(fd); return r; }

    /* Leer cabeceras HTTP manualmente para obtener Content-Length */
    char   raw[CR_MAX_RESP_LEN];
    int    total_read = 0;
    int    status     = 0;
    long long content_length = 0;

    /* Leer hasta encontrar \r\n\r\n */
    char hbuf[4096];
    int  hlen = 0;
    int  header_end = -1;

    while (hlen < (int)sizeof(hbuf) - 1) {
        int n = (int)SOCK_RECV(fd, hbuf + hlen, 1);
        if (n <= 0) break;
        hlen++;
        if (hlen >= 4 &&
            hbuf[hlen-4]=='\r' && hbuf[hlen-3]=='\n' &&
            hbuf[hlen-2]=='\r' && hbuf[hlen-1]=='\n') {
            header_end = hlen;
            break;
        }
    }
    hbuf[hlen] = '\0';

    /* Parsear status */
    sscanf(hbuf, "HTTP/%*s %d", &status);

    /* Parsear Content-Length */
    char *cl = strstr(hbuf, "Content-Length:");
    if (!cl) cl = strstr(hbuf, "content-length:");
    if (cl) sscanf(cl, "%*s %lld", &content_length);

    if (status != 200) {
        fprintf(stderr, "[transfer] Servidor respondio %d\n", status);
        cr_net_close(fd);
        return CR_ERR_RECV;
    }

    /* Abrir archivo destino */
    /* Crear directorios padre si no existen (best-effort) */
    char dir_buf[CR_MAX_PATH_LEN];
    strncpy(dir_buf, destino, sizeof(dir_buf) - 1);
    char *last_sep = NULL;
    for (char *p = dir_buf; *p; p++)
        if (*p == '/' || *p == '\\') last_sep = p;
    if (last_sep) {
        *last_sep = '\0';
#ifdef _WIN32
        _mkdir(dir_buf);
#else
        mkdir(dir_buf, 0755);
#endif
    }

    FILE *out = fopen(destino, "wb");
    if (!out) {
        fprintf(stderr, "[transfer] No se puede crear: %s (%s)\n",
                destino, strerror(errno));
        cr_net_close(fd);
        return CR_ERR_SYSTEM;
    }

    /* Recibir body con barra de progreso */
    char   buf[CHUNK_SIZE];
    long long recv_bytes = 0;

    printf("\n");
    print_bar("Recibiendo objetos", 0, content_length, 0);

    while (1) {
        int n = (int)SOCK_RECV(fd, buf, sizeof(buf));
        if (n <= 0) break;
        fwrite(buf, 1, n, out);
        recv_bytes += n;
        print_bar("Recibiendo objetos", recv_bytes, content_length, 0);
    }

    fclose(out);
    cr_net_close(fd);

    print_bar("Recibiendo objetos", recv_bytes, content_length, 1);

    if (recv_bytes == 0) {
        fprintf(stderr, "[transfer] No se recibieron bytes.\n");
        return CR_ERR_RECV;
    }

    printf("  Transferencia completada. %lld bytes recibidos.\n", recv_bytes);
    printf("  Guardado en: %s\n", destino);
    return CR_OK;
}
