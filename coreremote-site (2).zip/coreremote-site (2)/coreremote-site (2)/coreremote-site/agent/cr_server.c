/*
 * cr_server.c -- Loop TCP del agente CoreRemote
 *
 * Protocolo:
 *   [uint32 BE longitud][JSON bytes]   <- request
 *   [uint32 BE longitud][JSON bytes]   -> response
 *
 * El agente acepta una conexion a la vez (server.js la gestiona).
 * Cada request es un comando JSON que se ejecuta en el sistema local
 * mediante los mismos handlers que usaria el loop stdin.
 */

#include "cr_server.h"
#include "cr_cmd.h"
#include "cr_transfer.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>

/* ── Portabilidad ─────────────────────────────────────────────── */
#ifdef _WIN32
#  include <winsock2.h>
#  include <ws2tcpip.h>
#  include <windows.h>
#  include <direct.h>
#  include <process.h>
#  pragma comment(lib,"ws2_32.lib")
   typedef SOCKET cr_fd_t;
#  define CR_INVALID  INVALID_SOCKET
#  define CR_CLOSE(s) closesocket(s)
#  define CR_EINTR    WSAEINTR
static void sock_init(void){WSADATA w;WSAStartup(MAKEWORD(2,2),&w);}
#else
#  include <unistd.h>
#  include <sys/types.h>
#  include <sys/socket.h>
#  include <netinet/in.h>
#  include <arpa/inet.h>
#  include <signal.h>
#  include <sys/stat.h>
   typedef int cr_fd_t;
#  define CR_INVALID  (-1)
#  define CR_CLOSE(s) close(s)
#  define CR_EINTR    EINTR
static void sock_init(void){}
#endif

/* ── Helpers de framing ───────────────────────────────────────── */

/* Lee exactamente n bytes del socket */
static int recv_exact(cr_fd_t fd, char *buf, int n)
{
    int got = 0;
    while (got < n) {
        int r = (int)recv(fd, buf + got, n - got, 0);
        if (r <= 0) return -1;
        got += r;
    }
    return 0;
}

/* Envía exactamente n bytes */
static int send_exact(cr_fd_t fd, const char *buf, int n)
{
    int sent = 0;
    while (sent < n) {
        int r = (int)send(fd, buf + sent, n - sent, 0);
        if (r <= 0) return -1;
        sent += r;
    }
    return 0;
}

/* Lee un frame: [4 bytes BE len][payload]. Devuelve len o -1 */
static int recv_frame(cr_fd_t fd, char *buf, int bufsz)
{
    unsigned char hdr[4];
    if (recv_exact(fd, (char*)hdr, 4) < 0) return -1;
    int len = ((int)hdr[0] << 24) | ((int)hdr[1] << 16) |
              ((int)hdr[2] <<  8) |  (int)hdr[3];
    if (len <= 0 || len >= bufsz) return -1;
    if (recv_exact(fd, buf, len) < 0) return -1;
    buf[len] = '\0';
    return len;
}

/* Envía un frame: [4 bytes BE len][payload] */
static int send_frame(cr_fd_t fd, const char *buf, int len)
{
    unsigned char hdr[4];
    hdr[0] = (unsigned char)((len >> 24) & 0xFF);
    hdr[1] = (unsigned char)((len >> 16) & 0xFF);
    hdr[2] = (unsigned char)((len >>  8) & 0xFF);
    hdr[3] = (unsigned char)( len        & 0xFF);
    if (send_exact(fd, (char*)hdr, 4) < 0) return -1;
    return send_exact(fd, buf, len);
}

/* ── Mini parser JSON (solo extrae el valor de "cmd") ────────── */

/*
 * Extrae el valor de una clave string del JSON.
 * Muy simplificado — solo busca "key":"value".
 * Devuelve puntero al inicio del valor (sin comillas) y escribe len.
 */
static const char *json_str_val(const char *json, const char *key, int *vlen)
{
    char needle[128];
    snprintf(needle, sizeof(needle), "\"%s\"", key);
    const char *p = strstr(json, needle);
    if (!p) return NULL;
    p += strlen(needle);
    while (*p == ' ' || *p == ':' || *p == '\t') p++;
    if (*p != '"') return NULL;
    p++;
    const char *start = p;
    while (*p && *p != '"') {
        if (*p == '\\') p++; /* saltar escape */
        p++;
    }
    *vlen = (int)(p - start);
    return start;
}

/* ── Ejecutores de comandos del sistema ──────────────────────── */

#ifdef _WIN32
#  include <tlhelp32.h>

/* Ejecutar un comando del sistema y devolver stdout (max outbuf bytes) */
static int exec_cmd(const char *cmdline, char *outbuf, int outbuf_sz)
{
    SECURITY_ATTRIBUTES sa = {sizeof(sa), NULL, TRUE};
    HANDLE hr, hw;
    if (!CreatePipe(&hr, &hw, &sa, 0)) return -1;
    SetHandleInformation(hr, HANDLE_FLAG_INHERIT, 0);

    STARTUPINFOA si = {0};
    PROCESS_INFORMATION pi = {0};
    si.cb         = sizeof(si);
    si.dwFlags    = STARTF_USESTDHANDLES;
    si.hStdOutput = hw;
    si.hStdError  = hw;
    si.hStdInput  = GetStdHandle(STD_INPUT_HANDLE);

    char buf[4096];
    strncpy(buf, cmdline, sizeof(buf)-1);

    if (!CreateProcessA(NULL, buf, NULL, NULL, TRUE,
                        CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        CloseHandle(hr); CloseHandle(hw); return -1;
    }
    CloseHandle(hw);

    int total = 0;
    DWORD n;
    while (total < outbuf_sz - 1 &&
           ReadFile(hr, outbuf + total, outbuf_sz - 1 - total, &n, NULL) && n > 0)
        total += (int)n;
    outbuf[total] = '\0';
    CloseHandle(hr);
    WaitForSingleObject(pi.hProcess, 5000);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
    return total;
}

/* Ejecutar PowerShell inline */
static int exec_ps(const char *script, char *outbuf, int outbuf_sz)
{
    char cmdline[CR_MAX_JSON_BUF];
    snprintf(cmdline, sizeof(cmdline),
             "powershell -NoProfile -NonInteractive -Command \"%s\"", script);
    return exec_cmd(cmdline, outbuf, outbuf_sz);
}

#else
/* POSIX: popen */
static int exec_cmd(const char *cmdline, char *outbuf, int outbuf_sz)
{
    FILE *f = popen(cmdline, "r");
    if (!f) return -1;
    int total = 0;
    int n;
    while (total < outbuf_sz - 1 &&
           (n = (int)fread(outbuf + total, 1, outbuf_sz-1-total, f)) > 0)
        total += n;
    outbuf[total] = '\0';
    pclose(f);
    return total;
}
static int exec_ps(const char *script, char *outbuf, int outbuf_sz)
{
    (void)script;
    strncpy(outbuf, "powershell not available on POSIX", outbuf_sz-1);
    return -1;
}
#endif

/* ── Escape de strings para JSON ─────────────────────────────── */
static int json_escape(const char *src, char *dst, int dsz)
{
    int n = 0;
    for (; *src && n < dsz - 4; src++) {
        unsigned char c = (unsigned char)*src;
        if (c == '"')       { dst[n++]='\\'; dst[n++]='"';  }
        else if (c == '\\') { dst[n++]='\\'; dst[n++]='\\'; }
        else if (c == '\n') { dst[n++]='\\'; dst[n++]='n';  }
        else if (c == '\r') { dst[n++]='\\'; dst[n++]='r';  }
        else if (c == '\t') { dst[n++]='\\'; dst[n++]='t';  }
        else if (c < 0x20)  { /* skip control chars */ }
        else                { dst[n++] = (char)c; }
    }
    dst[n] = '\0';
    return n;
}

/* ── Construir respuesta JSON de éxito con un campo string ────── */
static int ok_str(char *buf, int sz, const char *key, const char *val)
{
    char esc[CR_MAX_JSON_BUF / 2];
    json_escape(val, esc, sizeof(esc));
    return snprintf(buf, sz, "{\"ok\":true,\"data\":{\"%s\":\"%s\"}}", key, esc);
}

/* Respuesta de error */
static int err_json(char *buf, int sz, const char *msg)
{
    char esc[512];
    json_escape(msg, esc, sizeof(esc));
    return snprintf(buf, sz, "{\"ok\":false,\"error\":\"%s\"}", esc);
}

/* ── Dispatcher principal ────────────────────────────────────── */
/*
 * Recibe el JSON del request, lo ejecuta y escribe la respuesta en resp.
 * Devuelve la longitud de resp o -1.
 */
static int dispatch(const char *req_json, char *resp, int resp_sz,
                    cr_session_t *sess)
{
    int vlen = 0;
    const char *cv = json_str_val(req_json, "cmd", &vlen);
    if (!cv || vlen <= 0) return err_json(resp, resp_sz, "cmd vacio");

    char cmd[256];
    if (vlen >= (int)sizeof(cmd)) vlen = (int)sizeof(cmd)-1;
    memcpy(cmd, cv, vlen);
    cmd[vlen] = '\0';

    char out[CR_MAX_JSON_BUF / 2];
    char esc[CR_MAX_JSON_BUF / 2];

    /* ── SESION ─────────────────────────────────────────── */
    if (strcmp(cmd,"cr.sesion.estado")==0 || strcmp(cmd,"estado")==0) {
        return snprintf(resp, resp_sz,
            "{\"ok\":true,\"data\":{\"estado\":\"activa\",\"agente\":\"" CR_AGENT_VERSION "\"}}");
    }
    if (strcmp(cmd,"cr.agente.version")==0) {
        return snprintf(resp, resp_sz,
            "{\"ok\":true,\"data\":{\"version\":\"" CR_AGENT_VERSION "\"}}");
    }
    if (strcmp(cmd,"cr.reloj.ver")==0) {
        time_t t = time(NULL);
        char ts[64];
        strftime(ts, sizeof(ts), "%d/%m/%Y %H:%M:%S", localtime(&t));
        return ok_str(resp, resp_sz, "fecha", ts);
    }
#ifdef _WIN32
    if (strcmp(cmd,"cr.equipo.nombre")==0) {
        char host[256] = {0};
        DWORD sz = sizeof(host);
        GetComputerNameA(host, &sz);
        return ok_str(resp, resp_sz, "nombre", host);
    }
    if (strcmp(cmd,"cr.equipo.usuario")==0) {
        char user[256] = {0};
        DWORD sz = sizeof(user);
        GetUserNameA(user, &sz);
        return ok_str(resp, resp_sz, "usuario", user);
    }
#endif

    /* ── DIRECTORIO ─────────────────────────────────────── */
    if (strcmp(cmd,"cr.directorio.actual")==0) {
        char cwd[CR_MAX_PATH_LEN] = {0};
#ifdef _WIN32
        GetCurrentDirectoryA(sizeof(cwd), cwd);
#else
        getcwd(cwd, sizeof(cwd));
#endif
        return ok_str(resp, resp_sz, "ruta", cwd);
    }
    if (strcmp(cmd,"cr.directorio.ver")==0) {
#ifdef _WIN32
        /* Obtener ruta del request o usar cwd */
        int rl=0;
        const char *rv = json_str_val(req_json,"ruta",&rl);
        char ruta[CR_MAX_PATH_LEN];
        if (rv && rl>0) { memcpy(ruta,rv,rl); ruta[rl]='\0'; }
        else GetCurrentDirectoryA(sizeof(ruta),ruta);

        char pat[CR_MAX_PATH_LEN+4];
        snprintf(pat,sizeof(pat),"%s\\*",ruta);
        WIN32_FIND_DATAA fd2;
        HANDLE hf = FindFirstFileA(pat,&fd2);
        if (hf==INVALID_HANDLE_VALUE)
            return err_json(resp,resp_sz,"No se pudo abrir el directorio");

        /* Construir array JSON */
        char arr[CR_MAX_JSON_BUF/2];
        int  ai=0;
        arr[ai++]='[';
        int first=1;
        do {
            if (strcmp(fd2.cFileName,".")==0||strcmp(fd2.cFileName,"..")==0) continue;
            if (!first) arr[ai++]=',';
            first=0;
            char ename[512];
            json_escape(fd2.cFileName,ename,sizeof(ename));
            int isdir=(fd2.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)?1:0;
            ai+=snprintf(arr+ai,sizeof(arr)-ai,
                "{\"nombre\":\"%s\",\"tipo\":\"%s\"}",
                ename, isdir?"carpeta":"archivo");
        } while(FindNextFileA(hf,&fd2) && ai<(int)sizeof(arr)-64);
        FindClose(hf);
        arr[ai++]=']'; arr[ai]='\0';

        json_escape(ruta,esc,sizeof(esc));
        return snprintf(resp,resp_sz,
            "{\"ok\":true,\"data\":{\"ruta\":\"%s\",\"entradas\":%s}}",
            esc, arr);
#else
        return ok_str(resp, resp_sz, "aviso", "Usa cr.directorio.ver en Windows");
#endif
    }

    /* ── PROCESO.LISTA ──────────────────────────────────── */
    if (strcmp(cmd,"cr.proceso.lista")==0) {
#ifdef _WIN32
        int fl=0;
        const char *fv = json_str_val(req_json,"filtro",&fl);
        char filtro[128]={0};
        if (fv && fl>0 && fl<(int)sizeof(filtro)) { memcpy(filtro,fv,fl); filtro[fl]='\0'; }

        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
        if (snap==INVALID_HANDLE_VALUE)
            return err_json(resp,resp_sz,"CreateToolhelp32Snapshot fallo");

        PROCESSENTRY32A pe; pe.dwSize=sizeof(pe);
        char arr[CR_MAX_JSON_BUF/2]; int ai=0;
        arr[ai++]='['; int first=1, total=0;

        if (Process32FirstA(snap,&pe)) {
            do {
                /* filtro por nombre */
                if (filtro[0]) {
                    char low[256]; strncpy(low,pe.szExeFile,255);
                    for(int i=0;low[i];i++) low[i]=(char)tolower((unsigned char)low[i]);
                    char flow[128]; strncpy(flow,filtro,127);
                    for(int i=0;flow[i];i++) flow[i]=(char)tolower((unsigned char)flow[i]);
                    if (!strstr(low,flow)) continue;
                }
                /* obtener memoria del proceso */
                HANDLE hp = OpenProcess(PROCESS_QUERY_INFORMATION|PROCESS_VM_READ,FALSE,pe.th32ProcessID);
                long long memkb = 0;
                if (hp) {
                    PROCESS_MEMORY_COUNTERS pmc={0}; pmc.cb=sizeof(pmc);
                    /* GetProcessMemoryInfo requiere psapi */
                    /* Usamos WorkingSetSize via NtQueryInformationProcess si disponible */
                    /* Fallback: 0 */
                    CloseHandle(hp);
                }
                if (!first) arr[ai++]=',';
                first=0; total++;
                char ename[256]; json_escape(pe.szExeFile,ename,sizeof(ename));
                ai+=snprintf(arr+ai,sizeof(arr)-ai,
                    "{\"nombre\":\"%s\",\"pid\":%lu,\"mem_kb\":%lld}",
                    ename,(unsigned long)pe.th32ProcessID,memkb);
                if (ai>(int)sizeof(arr)-128) break;
            } while(Process32NextA(snap,&pe));
        }
        CloseHandle(snap);
        arr[ai++]=']'; arr[ai]='\0';
        return snprintf(resp,resp_sz,
            "{\"ok\":true,\"data\":{\"total\":%d,\"procesos\":%s}}",total,arr);
#else
        exec_cmd("ps -eo pid,comm --no-headers", out, sizeof(out));
        json_escape(out, esc, sizeof(esc));
        return snprintf(resp, resp_sz,
            "{\"ok\":true,\"data\":{\"procesos_raw\":\"%s\"}}", esc);
#endif
    }

    /* ── PROCESO.CERRAR ─────────────────────────────────── */
    if (strcmp(cmd,"cr.proceso.cerrar")==0) {
        int pl=0; const char *pv=json_str_val(req_json,"pid",&pl);
        int cl=0; const char *cv2=json_str_val(req_json,"confirmar",&cl);
        if (!pv||pl<=0) return err_json(resp,resp_sz,"pid requerido");
        if (!cv2||strncmp(cv2,"SI",2)!=0) return err_json(resp,resp_sz,"confirmar=SI requerido");
        char pidstr[32]; memcpy(pidstr,pv,pl<31?pl:31); pidstr[pl<31?pl:31]='\0';
        DWORD pid2=(DWORD)atoi(pidstr);
#ifdef _WIN32
        HANDLE hp=OpenProcess(PROCESS_TERMINATE,FALSE,pid2);
        if(!hp) return err_json(resp,resp_sz,"No se pudo abrir el proceso");
        BOOL ok2=TerminateProcess(hp,0); CloseHandle(hp);
        if(!ok2) return err_json(resp,resp_sz,"TerminateProcess fallo");
#else
        if(kill((pid_t)pid2,SIGTERM)<0) return err_json(resp,resp_sz,"kill fallo");
#endif
        return snprintf(resp,resp_sz,
            "{\"ok\":true,\"data\":{\"pid\":%u,\"cerrado\":true}}",(unsigned)pid2);
    }

    /* ── VENTANA / CONTROL (via PowerShell en Windows) ──── */
    if (strncmp(cmd,"cr.control.",11)==0 || strncmp(cmd,"cr.ventana.",11)==0) {
#ifdef _WIN32
        /* Construir script PS desde el JSON raw — server.js ya lo hace mejor,
           aqui delegamos de vuelta al servidor si el agente no tiene PS embebido.
           Para el agente standalone lo ejecutamos via powershell.exe */
        char ps_script[2048];
        int  nl=0; const char *nv=json_str_val(req_json,"nombre",&nl);
        int  xl=0; const char *xv=json_str_val(req_json,"x",&xl);
        int  yl=0; const char *yv=json_str_val(req_json,"y",&yl);
        int  al=0; const char *av=json_str_val(req_json,"ancho",&al);
        int  hhl=0;const char *hv=json_str_val(req_json,"alto",&hhl);

        char nombre[256]={0},xstr[32]={0},ystr[32]={0},astr[32]={0},hstr[32]={0};
        if(nv&&nl>0){memcpy(nombre,nv,nl<255?nl:255);}
        if(xv&&xl>0){memcpy(xstr,xv,xl<31?xl:31);}
        if(yv&&yl>0){memcpy(ystr,yv,yl<31?yl:31);}
        if(av&&al>0){memcpy(astr,av,al<31?al:31);}
        if(hv&&hhl>0){memcpy(hstr,hv,hhl<31?hhl:31);}

        int x2=atoi(xstr), y2=atoi(ystr), w2=atoi(astr), h2=atoi(hstr);

        if (strcmp(cmd,"cr.control.buscar")==0||strcmp(cmd,"cr.ventana.lista")==0) {
            snprintf(ps_script,sizeof(ps_script),
                "Get-Process | Where-Object {$_.MainWindowHandle -ne 0 -and $_.ProcessName -like '*%s*'} | ForEach-Object {\"$($_.Id)|$($_.ProcessName)|$($_.MainWindowTitle)\"}",
                nombre);
            exec_ps(ps_script,out,sizeof(out));
            json_escape(out,esc,sizeof(esc));
            return snprintf(resp,resp_sz,
                "{\"ok\":true,\"data\":{\"resultado\":\"%s\"}}",esc);
        }

        if (strcmp(cmd,"cr.control.mover")==0||strcmp(cmd,"cr.control.colocar")==0||
            strcmp(cmd,"cr.ventana.posicionar")==0||strcmp(cmd,"cr.ventana.colocar")==0) {
            snprintf(ps_script,sizeof(ps_script),
                "Add-Type -TypeDefinition 'using System.Runtime.InteropServices;public class W{[DllImport(\"user32.dll\")]public static extern bool SetWindowPos(System.IntPtr h,System.IntPtr i,int x,int y,int cx,int cy,uint f);}' -ErrorAction SilentlyContinue;"
                "$p=Get-Process|Where-Object{$_.MainWindowHandle -ne 0 -and $_.ProcessName -like '*%s*'}|Select-Object -First 1;"
                "if($p){[W]::SetWindowPos($p.MainWindowHandle,[System.IntPtr]::Zero,%d,%d,%d,%d,0x0040)|Out-Null;\"ok|$($p.Id)\"}else{\"notfound\"}",
                nombre, x2, y2, w2>0?w2:800, h2>0?h2:600);
            exec_ps(ps_script,out,sizeof(out));
            if(strncmp(out,"ok",2)==0) {
                int pid2=0; sscanf(out,"ok|%d",&pid2);
                return snprintf(resp,resp_sz,
                    "{\"ok\":true,\"data\":{\"pid\":%d,\"x\":%d,\"y\":%d,\"ancho\":%d,\"alto\":%d}}",
                    pid2,x2,y2,w2,h2);
            }
            return err_json(resp,resp_sz,"Ventana no encontrada");
        }

        if (strcmp(cmd,"cr.control.minimizar")==0||strcmp(cmd,"cr.ventana.minimizar")==0) {
            snprintf(ps_script,sizeof(ps_script),
                "Add-Type -TypeDefinition 'using System.Runtime.InteropServices;public class W2{[DllImport(\"user32.dll\")]public static extern bool ShowWindow(System.IntPtr h,int n);}' -ErrorAction SilentlyContinue;"
                "$p=Get-Process|Where-Object{$_.MainWindowHandle -ne 0 -and $_.ProcessName -like '*%s*'}|Select-Object -First 1;"
                "if($p){[W2]::ShowWindow($p.MainWindowHandle,6)|Out-Null;\"ok|$($p.Id)\"}else{\"notfound\"}",
                nombre);
            exec_ps(ps_script,out,sizeof(out));
            if(strncmp(out,"ok",2)==0) {
                int pid2=0; sscanf(out,"ok|%d",&pid2);
                return snprintf(resp,resp_sz,
                    "{\"ok\":true,\"data\":{\"accion\":\"minimizado\",\"pid\":%d}}",pid2);
            }
            return err_json(resp,resp_sz,"Ventana no encontrada");
        }

        if (strcmp(cmd,"cr.control.restaurar")==0||strcmp(cmd,"cr.ventana.restaurar")==0) {
            snprintf(ps_script,sizeof(ps_script),
                "Add-Type -TypeDefinition 'using System.Runtime.InteropServices;public class W3{[DllImport(\"user32.dll\")]public static extern bool ShowWindow(System.IntPtr h,int n);}' -ErrorAction SilentlyContinue;"
                "$p=Get-Process|Where-Object{$_.MainWindowHandle -ne 0 -and $_.ProcessName -like '*%s*'}|Select-Object -First 1;"
                "if($p){[W3]::ShowWindow($p.MainWindowHandle,9)|Out-Null;\"ok|$($p.Id)\"}else{\"notfound\"}",
                nombre);
            exec_ps(ps_script,out,sizeof(out));
            if(strncmp(out,"ok",2)==0) {
                int pid2=0; sscanf(out,"ok|%d",&pid2);
                return snprintf(resp,resp_sz,
                    "{\"ok\":true,\"data\":{\"accion\":\"restaurado\",\"pid\":%d}}",pid2);
            }
            return err_json(resp,resp_sz,"Ventana no encontrada");
        }

        if (strcmp(cmd,"cr.control.maximizar")==0||strcmp(cmd,"cr.ventana.maximizar")==0) {
            snprintf(ps_script,sizeof(ps_script),
                "Add-Type -TypeDefinition 'using System.Runtime.InteropServices;public class W4{[DllImport(\"user32.dll\")]public static extern bool ShowWindow(System.IntPtr h,int n);}' -ErrorAction SilentlyContinue;"
                "$p=Get-Process|Where-Object{$_.MainWindowHandle -ne 0 -and $_.ProcessName -like '*%s*'}|Select-Object -First 1;"
                "if($p){[W4]::ShowWindow($p.MainWindowHandle,3)|Out-Null;\"ok|$($p.Id)\"}else{\"notfound\"}",
                nombre);
            exec_ps(ps_script,out,sizeof(out));
            if(strncmp(out,"ok",2)==0) {
                int pid2=0; sscanf(out,"ok|%d",&pid2);
                return snprintf(resp,resp_sz,
                    "{\"ok\":true,\"data\":{\"accion\":\"maximizado\",\"pid\":%d}}",pid2);
            }
            return err_json(resp,resp_sz,"Ventana no encontrada");
        }

        /* resumen */
        if (strcmp(cmd,"cr.control.resumen")==0) {
            snprintf(ps_script,sizeof(ps_script),
                "Add-Type -TypeDefinition 'using System.Runtime.InteropServices;public class W5{[DllImport(\"user32.dll\")]public static extern bool GetWindowRect(System.IntPtr h,out RECT r);[StructLayout(LayoutKind.Sequential)]public struct RECT{public int L,T,R,B;}}' -ErrorAction SilentlyContinue;"
                "$p=Get-Process|Where-Object{$_.MainWindowHandle -ne 0 -and $_.ProcessName -like '*%s*'}|Select-Object -First 1;"
                "if($p){$r=New-Object W5+RECT;[W5]::GetWindowRect($p.MainWindowHandle,[ref]$r)|Out-Null;\"$($p.Id)|$($p.ProcessName)|$($p.MainWindowTitle)|$($r.L)|$($r.T)|$($r.R-$r.L)|$($r.B-$r.T)\"}else{\"notfound\"}",
                nombre);
            exec_ps(ps_script,out,sizeof(out));
            /* trim */
            char *nl2=strchr(out,'\n'); if(nl2)*nl2='\0';
            char *cr2=strchr(out,'\r'); if(cr2)*cr2='\0';
            if(strcmp(out,"notfound")==0||out[0]=='\0')
                return err_json(resp,resp_sz,"Ventana no encontrada");
            int pid2=0,rx=0,ry=0,rw=0,rh=0;
            char rproc[256]={0},rtit[512]={0};
            sscanf(out,"%d|%255[^|]|%511[^|]|%d|%d|%d|%d",
                   &pid2,rproc,rtit,&rx,&ry,&rw,&rh);
            char ep[256],et[512];
            json_escape(rproc,ep,sizeof(ep));
            json_escape(rtit,et,sizeof(et));
            return snprintf(resp,resp_sz,
                "{\"ok\":true,\"data\":{\"pid\":%d,\"proceso\":\"%s\",\"titulo\":\"%s\",\"x\":%d,\"y\":%d,\"ancho\":%d,\"alto\":%d}}",
                pid2,ep,et,rx,ry,rw,rh);
        }
#endif
        return err_json(resp,resp_sz,"Comando de ventana no soportado en esta plataforma");
    }

    /* ── Comando no reconocido ──────────────────────────── */
    char errmsg[128];
    snprintf(errmsg,sizeof(errmsg),"Comando no reconocido: %.80s",cmd);
    return err_json(resp, resp_sz, errmsg);
}

/* ── cr_server_run ───────────────────────────────────────────── */
cr_result_t cr_server_run(cr_session_t *sess)
{
    sock_init();

#ifndef _WIN32
    signal(SIGPIPE, SIG_IGN);
#endif

    cr_fd_t listenfd = socket(AF_INET, SOCK_STREAM, 0);
    if (listenfd == CR_INVALID) {
        fprintf(stderr, "[cr_server] socket() fallo\n");
        return CR_ERR_CONNECT;
    }

    /* Reusar puerto al reiniciar */
    int opt = 1;
    setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, (const char*)&opt, sizeof(opt));

    /* Timeout en accept para poder enviar heartbeats */
#ifdef _WIN32
    DWORD tv_ms = 10000;
    setsockopt(listenfd, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv_ms, sizeof(tv_ms));
#else
    struct timeval tv_acc; tv_acc.tv_sec = 10; tv_acc.tv_usec = 0;
    setsockopt(listenfd, SOL_SOCKET, SO_RCVTIMEO, &tv_acc, sizeof(tv_acc));
#endif

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family      = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port        = htons(CR_AGENT_LISTEN_PORT);

    if (bind(listenfd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        fprintf(stderr, "[cr_server] bind() fallo en puerto %d\n", CR_AGENT_LISTEN_PORT);
        CR_CLOSE(listenfd);
        return CR_ERR_CONNECT;
    }

    listen(listenfd, CR_AGENT_BACKLOG);
    printf("[cr_server] Agente escuchando en 0.0.0.0:%d\n", CR_AGENT_LISTEN_PORT);
    printf("[cr_server] Esperando conexion de server.js...\n\n");

    /* Registrar en server.js */
    cr_agent_register(sess);

    /* Buffer de request/response */
    char *req_buf  = (char*)malloc(CR_MAX_JSON_BUF);
    char *resp_buf = (char*)malloc(CR_MAX_JSON_BUF);
    if (!req_buf || !resp_buf) {
        fprintf(stderr, "[cr_server] malloc fallo\n");
        CR_CLOSE(listenfd);
        return CR_ERR_NOMEM;
    }

    time_t last_hb = time(NULL);

    while (1) {
        /* Heartbeat cada 10 segundos aunque no haya conexiones */
        if (time(NULL) - last_hb >= 10) {
            cr_agent_heartbeat(sess);
            last_hb = time(NULL);
        }

        struct sockaddr_in client_addr;
#ifdef _WIN32
        int clen = sizeof(client_addr);
#else
        socklen_t clen = sizeof(client_addr);
#endif
        cr_fd_t clientfd = accept(listenfd,
                                  (struct sockaddr*)&client_addr, &clen);
        if (clientfd == CR_INVALID) continue;

        char client_ip[64] = {0};
        inet_ntop(AF_INET, &client_addr.sin_addr, client_ip, sizeof(client_ip));
        printf("[cr_server] Conexion desde %s\n", client_ip);

        /* Loop de mensajes en esta conexion */
        while (1) {
            int req_len = recv_frame(clientfd, req_buf, CR_MAX_JSON_BUF);
            if (req_len < 0) break;  /* conexion cerrada */

            printf("[cr_server] CMD: %.120s\n", req_buf);

            int resp_len = dispatch(req_buf, resp_buf, CR_MAX_JSON_BUF, sess);
            if (resp_len < 0) resp_len = err_json(resp_buf, CR_MAX_JSON_BUF, "error interno");

            if (send_frame(clientfd, resp_buf, resp_len) < 0) break;
        }

        CR_CLOSE(clientfd);
        printf("[cr_server] Conexion cerrada.\n");
    }

    free(req_buf);
    free(resp_buf);
    CR_CLOSE(listenfd);
    return CR_OK;
}
