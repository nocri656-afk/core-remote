/*
 * cr_transfer.h -- Transferencia de archivos entre agente y server.js
 *
 * ENVIAR  (agente -> servidor):
 *   POST /api/transfer/send
 *   Headers: X-CR-Origen, X-CR-Destino, Content-Length
 *   Body:    bytes del archivo en streaming
 *
 * RECIBIR (servidor -> agente):
 *   GET /api/transfer/recv?ruta=<ruta_absoluta>
 *   Body:    bytes del archivo en streaming
 *
 * Ambas funciones imprimen una barra de progreso en stdout:
 *   Enviando objetos  :  70% [=========>           ] 14.2 MB / 20.3 MB
 */
#ifndef CR_TRANSFER_H
#define CR_TRANSFER_H

#include "cr_types.h"
#include "cr_net.h"

/*
 * Envia un archivo local al servidor.
 *   sess    : sesion activa (host, port)
 *   origen  : ruta absoluta del archivo local a enviar
 *   destino : ruta absoluta destino en el servidor
 * Devuelve CR_OK o codigo de error.
 */
cr_result_t cr_transfer_send(cr_session_t *sess,
                             const char   *origen,
                             const char   *destino);

/*
 * Recibe un archivo del servidor y lo guarda localmente.
 *   sess    : sesion activa (host, port)
 *   origen  : ruta absoluta del archivo en el servidor
 *   destino : ruta absoluta local donde guardar el archivo
 * Devuelve CR_OK o codigo de error.
 */
cr_result_t cr_transfer_recv(cr_session_t *sess,
                             const char   *origen,
                             const char   *destino);

#endif /* CR_TRANSFER_H */
