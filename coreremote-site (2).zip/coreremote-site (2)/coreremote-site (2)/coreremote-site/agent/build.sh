#!/usr/bin/env bash
# =============================================================
# build.sh — Compilación del agente CoreRemote
# =============================================================
# Uso:
#   ./build.sh            # compilación normal
#   ./build.sh debug      # con símbolos de depuración
#   ./build.sh clean      # elimina el binario y objetos
# =============================================================

set -euo pipefail

# ── Configuración ──────────────────────────────────────────────
FINAL_NAME="xfx1"
CC="${CC:-gcc}"
SRCS="main.c cr_net.c cr_cmd.c cr_transfer.c cr_agent.c cr_server.c"
CFLAGS="-std=c11 -Wall -Wextra -Wpedantic -Wshadow \
        -Wformat=2 -Wno-unused-parameter"
LDFLAGS=""
BUILD_DIR="build"

# Ruta de public/agent relativa a la carpeta agent/
PUBLIC_AGENT="../public/agent"

# ── Detectar plataforma ─────────────────────────────────────────
OS="$(uname -s 2>/dev/null || echo 'Windows')"

case "$OS" in
    Linux*)
        LDFLAGS="-lpthread"
        TARGET="${FINAL_NAME}"
        ;;
    Darwin*)
        LDFLAGS=""
        TARGET="${FINAL_NAME}"
        ;;
    MINGW*|MSYS*|CYGWIN*|Windows*)
        LDFLAGS="-lws2_32"
        TARGET="${FINAL_NAME}.exe"
        ;;
    *)
        echo "Sistema no reconocido: $OS — usando flags POSIX por defecto."
        TARGET="${FINAL_NAME}"
        ;;
esac

# ── Acción: clean ──────────────────────────────────────────────
if [[ "${1:-}" == "clean" ]]; then
    echo "Limpiando artefactos..."
    rm -rf "$BUILD_DIR"
    rm -f "$PUBLIC_AGENT/$TARGET"
    echo "Listo."
    exit 0
fi

# ── Acción: debug ──────────────────────────────────────────────
if [[ "${1:-}" == "debug" ]]; then
    CFLAGS="$CFLAGS -g3 -O0 -DDEBUG"
    echo "Modo DEBUG activado."
else
    CFLAGS="$CFLAGS -O2 -DNDEBUG"
fi

# ── Crear directorio de salida ──────────────────────────────────
mkdir -p "$BUILD_DIR"
mkdir -p "$PUBLIC_AGENT"

# ── Compilar ───────────────────────────────────────────────────
echo "Compilando agente CoreRemote..."
echo "  CC      : $CC"
echo "  CFLAGS  : $CFLAGS"
echo "  LDFLAGS : $LDFLAGS"
echo "  OUTPUT  : $BUILD_DIR/$TARGET"
echo ""

# shellcheck disable=SC2086
"$CC" $CFLAGS \
    -I. \
    $SRCS \
    -o "$BUILD_DIR/$TARGET" \
    $LDFLAGS

# ── Copiar a public/agent/xfx1.exe ────────────────────────────
echo "Copiando a $PUBLIC_AGENT/$TARGET ..."
cp "$BUILD_DIR/$TARGET" "$PUBLIC_AGENT/$TARGET"

# ── Resultado ──────────────────────────────────────────────────
echo ""
echo "Compilacion exitosa"
echo "  build/     : $BUILD_DIR/$TARGET"
echo "  descarga   : $PUBLIC_AGENT/$TARGET"
echo ""
echo "Para usar:"
echo "  1. node ../server.js"
echo "  2. ./$BUILD_DIR/$TARGET"
echo ""
