/*
 * server.js — CoreRemote web server + proxy al agente nativo
 *
 * GET  /                        → archivos estáticos de /public
 * POST /api/cmd                 → reenvía al agente C (TCP 3002), fallback Node.js
 * GET  /api/status              → estado del servidor y del agente
 * POST /api/transfer/send       → upload stream al agente
 * GET  /api/transfer/recv?ruta= → download stream desde el agente
 * GET  /api/transfer/progress   → SSE de progreso de transferencia
 *
 * Flujo principal:
 *   Terminal web → POST /api/cmd → server.js → TCP 3002 → agente C → sistema
 */

'use strict';

const http   = require('node:http');
const net    = require('node:net');
const fs     = require('node:fs');
const path   = require('node:path');
const os     = require('node:os');

const publicRoot  = path.resolve(__dirname, 'public');
const port        = Number(process.env.PORT  || 3001);
const AGENT_HOST  = process.env.AGENT_HOST   || '127.0.0.1';
const AGENT_PORT  = Number(process.env.AGENT_PORT || 3002);

/* ═══════════════════════════════════════════════════════════════
 * REGISTRO DE AGENTES CONECTADOS
 * Map  id → { id, nombre, host, port, connectedAt, lastSeen }
 * Un agente se registra via POST /api/agent/register
 * ═══════════════════════════════════════════════════════════════ */
const agents = new Map();

function agentList() {
  return [...agents.values()].map(a => ({
    id          : a.id,
    nombre      : a.nombre,
    host        : a.host,
    port        : a.port,
    connectedAt : a.connectedAt,
    lastSeen    : a.lastSeen,
    online      : (Date.now() - a.lastSeen) < 15000, /* 15s sin heartbeat = offline */
  }));
}

/* Heartbeat automático: marcar offline si no hay actividad */
setInterval(function () {
  const now = Date.now();
  agents.forEach(function (a) {
    if (now - a.lastSeen > 60000) agents.delete(a.id); /* limpiar tras 60s */
  });
}, 10000);

/* ── Tipos de contenido estático ──────────────────────────────── */
const contentTypes = {
  '.html': 'text/html; charset=utf-8',
  '.css' : 'text/css; charset=utf-8',
  '.js'  : 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.dat' : 'application/json; charset=utf-8',
  '.svg' : 'image/svg+xml',
  '.png' : 'image/png',
  '.jpg' : 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.ico' : 'image/x-icon',
  '.webp': 'image/webp',
  '.exe' : 'application/octet-stream',
  '.msi' : 'application/octet-stream',
  '.deb' : 'application/octet-stream',
};

/* ── Cabeceras de seguridad ────────────────────────────────────── */
const SECURITY_HEADERS = {
  'X-Content-Type-Options' : 'nosniff',
  'Referrer-Policy'        : 'strict-origin-when-cross-origin',
  'Content-Security-Policy':
    "default-src 'self'; " +
    "img-src 'self' data:; " +
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
    "font-src 'self' https://fonts.gstatic.com; " +
    "script-src 'self'; " +
    "connect-src 'self'; " +
    "form-action 'self'; " +
    "base-uri 'self'",
};

/* ── Helper: leer body de una request ─────────────────────────── */
function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end',  () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

/* ── Helper: responder JSON ───────────────────────────────────── */
function jsonReply(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type'  : 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control' : 'no-store',
    ...SECURITY_HEADERS,
  });
  res.end(body);
}

/* ═══════════════════════════════════════════════════════════════
 * sendToAgent
 * Envía un JSON al agente C via TCP (protocolo framing 4 bytes BE).
 * agentId opcional — si se pasa, usa el host/port de ese agente.
 * Devuelve la respuesta JSON parseada, o null si el agente no está.
 * ═══════════════════════════════════════════════════════════════ */
function sendToAgent(obj, agentId) {
  let host = AGENT_HOST;
  let aport = AGENT_PORT;

  if (agentId) {
    const a = agents.get(agentId);
    if (a) { host = a.host; aport = a.port; }
  }

  return new Promise(resolve => {
    const payload = Buffer.from(JSON.stringify(obj), 'utf8');
    const header  = Buffer.alloc(4);
    header.writeUInt32BE(payload.length, 0);
    const frame   = Buffer.concat([header, payload]);

    const sock = net.createConnection({ host, port: aport });
    sock.setTimeout(8000);

    let recvBuf  = Buffer.alloc(0);
    let resolved = false;

    function done(result) {
      if (!resolved) { resolved = true; sock.destroy(); resolve(result); }
    }

    sock.on('connect', () => { sock.write(frame); });
    sock.on('data', chunk => {
      recvBuf = Buffer.concat([recvBuf, chunk]);
      if (recvBuf.length < 4) return;
      const respLen = recvBuf.readUInt32BE(0);
      if (recvBuf.length < 4 + respLen) return;
      const respJson = recvBuf.slice(4, 4 + respLen).toString('utf8');
      try { done(JSON.parse(respJson)); }
      catch { done({ ok: false, error: 'respuesta invalida del agente' }); }
    });
    sock.on('timeout', () => done(null));
    sock.on('error',   () => done(null));
  });
}

/* Estado de conexión con el agente por defecto */
let agentOnline = false;

/* ═══════════════════════════════════════════════════════════════
 * TRANSFERENCIAS ACTIVAS
 * ═══════════════════════════════════════════════════════════════ */
const transfers = new Map();

/* ═══════════════════════════════════════════════════════════════
 * MARCADORES  { nombre → { nombre, ruta } }
 * ═══════════════════════════════════════════════════════════════ */
const marcadores = new Map();

/* ═══════════════════════════════════════════════════════════════
 * POSICIONES GUARDADAS  { nombre → { nombre, pid, x, y, ancho, alto } }
 * ═══════════════════════════════════════════════════════════════ */
const posiciones = new Map();

function newTransferId() {
  return 'TR-' + Math.floor(Math.random() * 0xFFFFFF).toString(16).toUpperCase().padStart(6,'0');
}

/* ─────────────────────────────────────────────────────────────
 * handleTransferSend
 * POST /api/transfer/send
 * Headers requeridos:
 *   X-CR-Origen  : ruta de origen (informativo)
 *   X-CR-Destino : ruta destino ABSOLUTA en este servidor
 *   Content-Length (opcional, para progreso)
 * Body: bytes del archivo
 * ───────────────────────────────────────────────────────────── */
function handleTransferSend(req, res) {
  const destino = req.headers['x-cr-destino'];
  const origen  = req.headers['x-cr-origen'] || 'desconocido';

  if (!destino) {
    res.writeHead(400, {'Content-Type':'application/json'});
    res.end(JSON.stringify({ ok: false, error: 'Cabecera X-CR-Destino requerida' }));
    return;
  }

  /* Seguridad: solo rutas absolutas */
  if (!path.isAbsolute(destino)) {
    res.writeHead(400, {'Content-Type':'application/json'});
    res.end(JSON.stringify({ ok: false, error: 'destino debe ser ruta absoluta' }));
    return;
  }

  const total = parseInt(req.headers['content-length'] || '0', 10);
  const id    = newTransferId();
  const tr    = { id, origen, destino, total, transferido: 0, estado: 'activa', error: null };
  transfers.set(id, tr);
  console.log(`[transfer/send] ${id} ${origen} -> ${destino} (${total} bytes)`);

  /* Crear directorio destino si no existe */
  try { fs.mkdirSync(path.dirname(destino), { recursive: true }); } catch (_) {}

  const writeStream = fs.createWriteStream(destino);

  req.on('data', chunk => {
    tr.transferido += chunk.length;
  });

  req.on('error', err => {
    tr.estado = 'error';
    tr.error  = err.message;
    writeStream.destroy();
  });

  writeStream.on('error', err => {
    tr.estado = 'error';
    tr.error  = err.message;
    if (!res.headersSent) {
      res.writeHead(500, {'Content-Type':'application/json'});
      res.end(JSON.stringify({ ok: false, error: err.message, id }));
    }
  });

  req.pipe(writeStream);

  writeStream.on('finish', () => {
    tr.estado      = 'completada';
    tr.transferido = tr.total || tr.transferido;
    console.log(`[transfer/send] ${id} completada`);
    res.writeHead(200, {'Content-Type':'application/json'});
    res.end(JSON.stringify({ ok: true, id, destino, bytes: tr.transferido }));
  });
}

/* ─────────────────────────────────────────────────────────────
 * handleTransferRecv
 * GET /api/transfer/recv?ruta=/ruta/al/archivo
 * Envía el archivo al cliente con progreso via Content-Length
 * ───────────────────────────────────────────────────────────── */
function handleTransferRecv(req, res) {
  const url    = new URL(req.url, 'http://localhost');
  const ruta   = url.searchParams.get('ruta');
  const destino= url.searchParams.get('destino') || path.basename(ruta || 'archivo');

  if (!ruta) {
    res.writeHead(400, {'Content-Type':'application/json'});
    res.end(JSON.stringify({ ok: false, error: 'Param ruta requerido' }));
    return;
  }

  if (!path.isAbsolute(ruta)) {
    res.writeHead(400, {'Content-Type':'application/json'});
    res.end(JSON.stringify({ ok: false, error: 'ruta debe ser absoluta' }));
    return;
  }

  fs.stat(ruta, (err, stats) => {
    if (err || !stats.isFile()) {
      res.writeHead(404, {'Content-Type':'application/json'});
      res.end(JSON.stringify({ ok: false, error: `No se encontro: ${ruta}` }));
      return;
    }

    const id = newTransferId();
    const tr = { id, origen: ruta, destino, total: stats.size, transferido: 0, estado: 'activa', error: null };
    transfers.set(id, tr);
    console.log(`[transfer/recv] ${id} ${ruta} (${stats.size} bytes)`);

    res.writeHead(200, {
      'Content-Type'       : 'application/octet-stream',
      'Content-Length'     : stats.size,
      'Content-Disposition': `attachment; filename="${path.basename(ruta)}"`,
      'X-CR-Transfer-ID'   : id,
      'Cache-Control'      : 'no-store',
    });

    const readStream = fs.createReadStream(ruta);
    readStream.on('data', chunk => { tr.transferido += chunk.length; });
    readStream.on('end',  ()    => { tr.estado = 'completada'; });
    readStream.on('error', e   => { tr.estado = 'error'; tr.error = e.message; });
    readStream.pipe(res);
  });
}

/* ─────────────────────────────────────────────────────────────
 * handleTransferProgress
 * GET /api/transfer/progress?id=TR-XXXXXX
 * Server-Sent Events: envía { id, total, transferido, pct, estado }
 * cada 200 ms hasta que la transferencia termina
 * ───────────────────────────────────────────────────────────── */
function handleTransferProgress(req, res) {
  const url = new URL(req.url, 'http://localhost');
  const id  = url.searchParams.get('id');

  res.writeHead(200, {
    'Content-Type' : 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache',
    'Connection'   : 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  res.flushHeaders();

  const send = () => {
    const tr = transfers.get(id);
    if (!tr) {
      res.write(`data: ${JSON.stringify({ error: 'ID no encontrado' })}\n\n`);
      res.end();
      return;
    }
    const pct = tr.total > 0 ? Math.round((tr.transferido / tr.total) * 100) : 0;
    res.write(`data: ${JSON.stringify({
      id          : tr.id,
      total       : tr.total,
      transferido : tr.transferido,
      pct,
      estado      : tr.estado,
      error       : tr.error,
    })}\n\n`);
    if (tr.estado === 'completada' || tr.estado === 'error') {
      res.end();
    }
  };

  const interval = setInterval(() => {
    if (res.writableEnded) { clearInterval(interval); return; }
    send();
    const tr = transfers.get(id);
    if (tr && (tr.estado === 'completada' || tr.estado === 'error')) {
      clearInterval(interval);
    }
  }, 200);

  req.on('close', () => clearInterval(interval));
  send(); /* envío inmediato inicial */
}

/* ═══════════════════════════════════════════════════════════════
 * dispatchCmd — SOLO proxy al agente C
 * Si el agente no está corriendo devuelve error claro.
 * server.js NO ejecuta ningún comando del sistema.
 * ═══════════════════════════════════════════════════════════════ */
async function dispatchCmd(obj, agentId) {
  const cmd = (obj.cmd || '').trim();
  if (!cmd) return { ok: false, error: 'cmd vacio' };

  /* Transferencias locales */
  if (cmd === 'cr.transferencia.lista') {
    const lista = [...transfers.values()].map(t => ({
      id: t.id, origen: t.origen, destino: t.destino,
      total: t.total, transferido: t.transferido,
      pct: t.total > 0 ? Math.round((t.transferido/t.total)*100) : 0,
      estado: t.estado,
    }));
    return { ok: true, data: { transferencias: lista } };
  }
  if (cmd === 'cr.transferencia.estado') {
    const tr = transfers.get(obj.id);
    if (!tr) return { ok: false, error: `ID no encontrado: ${obj.id}` };
    return { ok: true, data: {
      id: tr.id, estado: tr.estado,
      pct: tr.total > 0 ? Math.round((tr.transferido/tr.total)*100) : 0,
      transferido: tr.transferido, total: tr.total,
    }};
  }
  if (cmd === 'cr.transferencia.cancelar') {
    const tr = transfers.get(obj.id);
    if (!tr) return { ok: false, error: `ID no encontrado: ${obj.id}` };
    tr.estado = 'cancelada';
    return { ok: true, data: { id: obj.id, estado: 'cancelada' } };
  }

  /* Todo lo demás → agente C seleccionado */
  const agentResp = await sendToAgent(obj, agentId);

  if (agentResp === null) {
    agentOnline = false;
    const target = agentId ? `agente ${agentId}` : `${AGENT_HOST}:${AGENT_PORT}`;
    return {
      ok   : false,
      error: `Agente no disponible (${target}). Inicia xfx1.exe primero.`,
    };
  }

  agentOnline = true;
  /* actualizar lastSeen del agente si está registrado */
  if (agentId && agents.has(agentId)) agents.get(agentId).lastSeen = Date.now();
  return agentResp;
}

/* ═══════════════════════════════════════════════════════════════
 * HTTP SERVER
 * ═══════════════════════════════════════════════════════════════ */
const server = http.createServer(async (req, res) => {
  const method = req.method || 'GET';

  let pathname;
  try {
    pathname = decodeURIComponent(new URL(req.url || '/', 'http://localhost').pathname);
  } catch {
    res.writeHead(400); res.end('Bad request'); return;
  }

  /* ── POST /api/transfer/send ──────────────────────────────── */
  if (pathname === '/api/transfer/send' && method === 'POST') {
    return handleTransferSend(req, res);
  }

  /* ── GET /api/transfer/recv ───────────────────────────────── */
  if (pathname === '/api/transfer/recv' && method === 'GET') {
    return handleTransferRecv(req, res);
  }

  /* ── GET /api/transfer/progress ──────────────────────────── */
  if (pathname === '/api/transfer/progress' && method === 'GET') {
    return handleTransferProgress(req, res);
  }

  /* ── POST /api/agent/register ────────────────────────────────── */
  if (pathname === '/api/agent/register' && method === 'POST') {
    let obj;
    try { const raw = await readBody(req); obj = JSON.parse(raw); }
    catch { return jsonReply(res, 400, { ok: false, error: 'JSON invalido' }); }
    const id     = obj.id     || ('ag-' + Date.now().toString(36));
    const nombre = obj.nombre || obj.host || id;
    const ahost  = obj.host   || (req.socket.remoteAddress || '127.0.0.1');
    const aport  = Number(obj.port) || AGENT_PORT;
    agents.set(id, { id, nombre, host: ahost, port: aport,
                     connectedAt: Date.now(), lastSeen: Date.now() });
    console.log(`[agent] registrado: ${id} (${nombre}) @ ${ahost}:${aport}`);
    return jsonReply(res, 200, { ok: true, id });
  }

  /* ── POST /api/agent/heartbeat ────────────────────────────────── */
  if (pathname === '/api/agent/heartbeat' && method === 'POST') {
    let obj;
    try { const raw = await readBody(req); obj = JSON.parse(raw); }
    catch { return jsonReply(res, 400, { ok: false, error: 'JSON invalido' }); }
    const a = agents.get(obj.id);
    if (a) { a.lastSeen = Date.now(); return jsonReply(res, 200, { ok: true }); }
    return jsonReply(res, 404, { ok: false, error: 'agente no encontrado' });
  }

  /* ── GET /api/agent/list ──────────────────────────────────────── */
  if (pathname === '/api/agent/list' && method === 'GET') {
    const list = agentList();
    if (list.length === 0) {
      const r = await sendToAgent({ cmd: 'cr.sesion.estado' }, null);
      if (r !== null) {
        const defId = 'default';
        if (!agents.has(defId)) {
          agents.set(defId, { id: defId, nombre: AGENT_HOST, host: AGENT_HOST,
                              port: AGENT_PORT, connectedAt: Date.now(), lastSeen: Date.now() });
        } else { agents.get(defId).lastSeen = Date.now(); }
      }
    }
    return jsonReply(res, 200, { ok: true, agentes: agentList() });
  }

  /* ── POST /api/cmd ────────────────────────────────────────── */
  if (pathname === '/api/cmd' && method === 'POST') {
    let obj;
    try {
      const raw = await readBody(req);
      obj = JSON.parse(raw);
    } catch {
      return jsonReply(res, 400, { ok: false, error: 'JSON inválido' });
    }

    console.log(`[api/cmd] ${JSON.stringify(obj)}`);
    const result = await dispatchCmd(obj, obj._agentId || null);
    return jsonReply(res, result.ok ? 200 : 400, result);
  }

  /* ── GET /api/status ──────────────────────────────────────── */
  if (pathname === '/api/status' && method === 'GET') {
    return jsonReply(res, 200, {
      ok          : true,
      version     : '1.0.0',
      uptime      : process.uptime(),
      host        : os.hostname(),
      cwd         : process.cwd(),
      agent       : {
        host   : AGENT_HOST,
        port   : AGENT_PORT,
        online : agentOnline,
      },
    });
  }

  /* ── Métodos no permitidos para rutas estáticas ───────────── */
  if (method !== 'GET' && method !== 'HEAD') {
    res.writeHead(405, { Allow: 'GET, HEAD', 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Method not allowed');
    return;
  }

  /* ── Rutas estáticas ──────────────────────────────────────── */
  if (pathname === '/pin'      || pathname === '/pin/')      pathname = '/pin/index.html';
  else if (pathname === '/descargas' || pathname === '/descargas/') pathname = '/descargas/index.html';
  else if (pathname === '/terminal'  || pathname === '/terminal/')  pathname = '/terminal/index.html';
  else if (pathname === '/datos'     || pathname === '/datos/')     { res.writeHead(403); res.end('Forbidden'); return; }
  else if (pathname === '/')                                         pathname = '/index.html';

  const filePath = path.resolve(publicRoot, `.${pathname}`);
  if (!filePath.startsWith(`${publicRoot}${path.sep}`)) {
    res.writeHead(400); res.end('Bad request'); return;
  }

  fs.stat(filePath, (statErr, stats) => {
    if (statErr || !stats.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end('Not found');
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    const isDownload = ext === '.exe' || ext === '.msi' || ext === '.deb';
    const headers = {
      'Content-Type'  : contentTypes[ext] || 'application/octet-stream',
      'Content-Length': stats.size,
      'Cache-Control' : isDownload ? 'no-store' : 'no-cache',
      ...SECURITY_HEADERS,
    };
    /* Forzar descarga para binarios */
    if (isDownload) {
      headers['Content-Disposition'] = `attachment; filename="${path.basename(filePath)}"`;
    }
    res.writeHead(200, headers);
    if (method === 'HEAD') { res.end(); return; }
    fs.createReadStream(filePath).pipe(res);
  });
});

server.listen(port, '0.0.0.0', () => {
  console.log(`CoreRemote server  →  http://localhost:${port}`);
  console.log(`API endpoint       →  POST http://localhost:${port}/api/cmd`);
});
