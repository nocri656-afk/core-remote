/**
 * cursor.js — Cursor bloque ancho para terminal xfx1
 * Mide el ancho real del texto usando un span del DOM (respeta letter-spacing y font).
 */
(function () {
  const input = document.getElementById('term-input');
  if (!input) return;

  /* Span oculto para medir el texto exacto con los estilos reales */
  const ruler = document.createElement('span');
  ruler.setAttribute('aria-hidden', 'true');
  ruler.style.cssText = [
    'position:absolute',
    'visibility:hidden',
    'white-space:pre',
    'pointer-events:none',
    'top:0',
    'left:0',
  ].join(';');
  document.body.appendChild(ruler);

  /* Cursor bloque */
  const cursor = document.createElement('span');
  cursor.id = 'xfx1-cursor';
  cursor.setAttribute('aria-hidden', 'true');
  cursor.style.cssText = [
    'position:absolute',
    'top:50%',
    'transform:translateY(-50%)',
    'width:11px',
    'height:1.15em',
    'background:#111',
    'pointer-events:none',
    'z-index:1',
    'animation:xfx1blink 1s step-end infinite',
  ].join(';');

  /* Keyframes */
  if (!document.getElementById('xfx1-cursor-style')) {
    const st = document.createElement('style');
    st.id = 'xfx1-cursor-style';
    st.textContent = `
      @keyframes xfx1blink {
        0%,100% { opacity:1; }
        50%      { opacity:0; }
      }
    `;
    document.head.appendChild(st);
  }

  const wrap = input.parentElement;
  wrap.style.position   = 'relative';
  wrap.style.pointerEvents = 'none'; /* el click atraviesa hasta el input */
  input.style.pointerEvents = 'auto'; /* pero el input sí lo recibe */
  wrap.appendChild(cursor);

  /* Copiar estilos de fuente del input al ruler para medir igual */
  function syncRulerFont() {
    const cs = window.getComputedStyle(input);
    ruler.style.font          = cs.font;
    ruler.style.letterSpacing = cs.letterSpacing;
    ruler.style.fontWeight    = cs.fontWeight;
  }

  /* Medir ancho real del texto escrito */
  function measureText(text) {
    syncRulerFont();
    ruler.textContent = text;
    return ruler.getBoundingClientRect().width;
  }

  function updateCursor() {
    /* Usar requestAnimationFrame para esperar que el DOM pinte el valor nuevo */
    requestAnimationFrame(function () {
      /* Medir solo hasta la posición real del caret, no el texto completo */
      const pos  = input.selectionStart != null ? input.selectionStart : input.value.length;
      const left = measureText(input.value.slice(0, pos));
      cursor.style.left = left + 'px';
    });
  }

  input.addEventListener('input',   updateCursor);
  input.addEventListener('keydown', updateCursor);
  input.addEventListener('keyup',   updateCursor);
  input.addEventListener('click',   updateCursor);
  input.addEventListener('paste',   updateCursor);

  input.addEventListener('focus', function () {
    cursor.style.animationName = 'xfx1blink';
    cursor.style.background    = '#111';
    cursor.style.opacity       = '1';
  });
  input.addEventListener('blur', function () {
    cursor.style.animationName = 'none';
    cursor.style.opacity       = '0.3';
    cursor.style.background    = '#888';
  });

  updateCursor();
})();
