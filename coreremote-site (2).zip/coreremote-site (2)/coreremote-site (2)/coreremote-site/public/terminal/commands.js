/**
 * commands.js — reservado para extensiones futuras.
 * La lógica principal está en engine.js.
 */
