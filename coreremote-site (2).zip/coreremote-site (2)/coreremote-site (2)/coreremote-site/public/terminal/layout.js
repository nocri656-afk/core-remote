/**
 * layout.js — Ajusta el ancho y tamaño de texto de la terminal xfx1
 */
(function () {
  const term = document.getElementById('term-full');
  if (!term) return;

  term.style.padding       = '20px 60px 40px 16px';
  term.style.fontSize      = '18px';
  term.style.lineHeight    = '1.35';
  term.style.fontFamily    = "'Courier New', Courier, monospace";
  term.style.letterSpacing = '0.06em';
  term.style.fontWeight    = '600';

  const input = document.getElementById('term-input');
  if (input) {
    input.style.fontSize      = '18px';
    input.style.fontFamily    = "'Courier New', Courier, monospace";
    input.style.letterSpacing = '0.06em';
    input.style.fontWeight    = '600';
    input.style.accentColor   = '#e03e2d';
  }

  /* Selección en rojo para todo el texto de la terminal */
  const selStyle = document.createElement('style');
  selStyle.textContent = `
    #term-full::selection,
    #term-full *::selection {
      background: #e03e2d !important;
      color: #fff !important;
    }
    #term-full::-moz-selection,
    #term-full *::-moz-selection {
      background: #e03e2d !important;
      color: #fff !important;
    }
  `;
  document.head.appendChild(selStyle);
})();
