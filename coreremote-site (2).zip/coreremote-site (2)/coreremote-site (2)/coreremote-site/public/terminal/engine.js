(function () {
  const container  = document.getElementById('term-full');
  const activeLine = document.getElementById('term-active-line');
  const input      = document.getElementById('term-input');
  const history    = [];
  let histIdx      = -1;

  /* Carga commands.dat desde el servidor */
  let cmdData = null;
  fetch('/terminal/commands.dat')
    .then(function (r) { return r.json(); })
    .then(function (data) { cmdData = data; })
    .catch(function () { cmdData = null; });

  /* ── AUTOCOMPLETADO ─────────────────────────────────────────── */

  /* Construir lista plana de todos los comandos del dat */
  function getAllCommands() {
    if (!cmdData) return [];
    var list = [];
    cmdData.grupos.forEach(function (g) {
      g.comandos.forEach(function (c) {
        list.push(typeof c === 'string' ? c : c.cmd);
      });
    });
    return list;
  }

  /* Dropdown */
  var acBox      = null;   /* el <ul> flotante */
  var acMatches  = [];     /* sugerencias actuales */
  var acIdx      = -1;     /* item seleccionado (-1 = ninguno) */

  function createAcBox() {
    if (acBox) return;
    acBox = document.createElement('ul');
    acBox.id = 'xfx1-ac';
    acBox.setAttribute('role', 'listbox');
    acBox.style.cssText = [
      'position:absolute',
      'bottom:calc(100% + 4px)',
      'left:0',
      'min-width:320px',
      'max-width:600px',
      'max-height:220px',
      'overflow-y:auto',
      'background:#fff',
      'border:1px solid #d1d5db',
      'border-radius:6px',
      'box-shadow:0 4px 12px rgba(0,0,0,.12)',
      'list-style:none',
      'padding:4px 0',
      'margin:0',
      'z-index:100',
      'font-family:\'Courier New\',Courier,monospace',
      'font-size:14px',
    ].join(';');

    /* El wrap del input ya tiene position:relative desde cursor.js */
    var wrap = input.parentElement;
    wrap.style.position = 'relative';
    wrap.appendChild(acBox);
  }

  function destroyAc() {
    if (acBox) { acBox.remove(); acBox = null; }
    acMatches = [];
    acIdx     = -1;
  }

  function renderAc() {
    if (!acBox || acMatches.length === 0) { destroyAc(); return; }

    acBox.innerHTML = '';
    acMatches.forEach(function (cmd, i) {
      var li = document.createElement('li');
      li.setAttribute('role', 'option');
      li.setAttribute('aria-selected', i === acIdx ? 'true' : 'false');
      li.style.cssText = [
        'padding:4px 12px',
        'cursor:pointer',
        'white-space:nowrap',
        'overflow:hidden',
        'text-overflow:ellipsis',
        'color:#111',
        'background:' + (i === acIdx ? '#f3f4f6' : 'transparent'),
        'border-left:3px solid ' + (i === acIdx ? '#16a34a' : 'transparent'),
      ].join(';');

      /* Resaltar la parte que coincide */
      var typed = input.value;
      var idx   = cmd.toLowerCase().indexOf(typed.toLowerCase());
      if (idx >= 0 && typed.length > 0) {
        li.appendChild(document.createTextNode(cmd.slice(0, idx)));
        var mark = document.createElement('b');
        mark.style.color = '#16a34a';
        mark.textContent = cmd.slice(idx, idx + typed.length);
        li.appendChild(mark);
        li.appendChild(document.createTextNode(cmd.slice(idx + typed.length)));
      } else {
        li.textContent = cmd;
      }

      li.addEventListener('mousedown', function (e) {
        e.preventDefault(); /* no pierde el foco el input */
        applyAc(cmd);
      });
      li.addEventListener('mouseover', function () {
        acIdx = i;
        renderAc();
      });

      acBox.appendChild(li);
    });

    /* Scroll al item activo */
    if (acIdx >= 0) {
      var active = acBox.children[acIdx];
      if (active) active.scrollIntoView({ block: 'nearest' });
    }
  }

  function applyAc(cmd) {
    input.value = cmd;
    destroyAc();
    input.focus();
    /* Dispara actualización del cursor */
    input.dispatchEvent(new Event('input'));
  }

  function updateAc() {
    var val = input.value;
    if (!val || !cmdData) { destroyAc(); return; }

    var all     = getAllCommands();
    var lower   = val.toLowerCase();
    var matches = all.filter(function (c) {
      return c.toLowerCase().indexOf(lower) >= 0;
    });

    /* No mostrar si solo hay una coincidencia exacta */
    if (matches.length === 0 || (matches.length === 1 && matches[0] === val)) {
      destroyAc(); return;
    }

    acMatches = matches;
    acIdx     = -1;
    createAcBox();
    renderAc();
  }

  /* ── COMANDOS BUILT-IN ──────────────────────────────────────── */

  const commands = {
    clear()   { return null; },
    whoami()  { return ['xfx1-user']; },
    date()    { return [new Date().toLocaleString('es-ES')]; },
    version() { return ['xfx1 v1.0.0 — CoreRemote Terminal']; },
    echo(a)   { return [a.join(' ')]; },
  };

  /* ── HELPERS DOM ────────────────────────────────────────────── */

  function insertBefore(el) { container.insertBefore(el, activeLine); }

  function addLine(text, cls) {
    const s = document.createElement('span');
    s.className = 'term-line ' + (cls || '');
    s.textContent = text;
    insertBefore(s);
    return s;
  }

  function addBlank() {
    const s = document.createElement('span');
    s.className = 'term-line term-line--blank';
    insertBefore(s);
  }

  function scrollToInput() {
    container.scrollTop = container.scrollHeight;
  }

  /* ── BARRA DE PROGRESO (estilo git clone) ───────────────────── */
  /*
   * Crea una línea mutable en la terminal y devuelve una función
   * update(pct, transferido, total, estado) que la actualiza in-place.
   *
   * Ejemplo de salida:
   *   Recibiendo objetos:  70% [=========>    ] 14.2 MB / 20.3 MB
   *   Recibiendo objetos: 100% [=============] 20.3 MB / 20.3 MB — listo
   */
  function createProgressLine(label) {
    const span = document.createElement('span');
    span.className = 'term-line';
    span.style.fontFamily = "'Courier New', monospace";
    insertBefore(span);
    scrollToInput();

    function fmtBytes(b) {
      if (b === 0) return '0 B';
      const u = ['B','KB','MB','GB'];
      const i = Math.floor(Math.log(b) / Math.log(1024));
      return (b / Math.pow(1024, i)).toFixed(1) + ' ' + u[i];
    }

    function update(pct, transferido, total, estado) {
      const BAR_W   = 20;
      const filled  = Math.round((pct / 100) * BAR_W);
      const empty   = BAR_W - filled;
      const bar     = '='.repeat(filled > 0 ? filled - 1 : 0) +
                      (filled > 0 ? '>' : '') +
                      ' '.repeat(empty);
      const pctStr  = String(pct).padStart(3) + '%';
      const sizeStr = total > 0
        ? fmtBytes(transferido) + ' / ' + fmtBytes(total)
        : fmtBytes(transferido);
      const suffix  = estado === 'completada' ? ' \u2014 listo.'
                    : estado === 'error'       ? ' \u2014 ERROR'
                    : estado === 'cancelada'   ? ' \u2014 cancelado'
                    : '';

      span.textContent =
        '  ' + label + ': ' + pctStr +
        ' [' + bar + '] ' + sizeStr + suffix;

      scrollToInput();
    }

    return { update, span };
  }

  /* ── TRANSFERENCIA CON PROGRESO (SSE) ───────────────────────── */
  function runTransfer(trimmed, params, cmdVerb) {
    /* 1. Enviar el comando cr.transferencia.* al servidor */
    fetch('/api/cmd', {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify(params),
    })
    .then(function (r) { return r.json(); })
    .then(function (res) {
      if (!res.ok) {
        addLine('  Error: ' + (res.error || 'respuesta invalida'), 'term-line--err');
        addBlank(); scrollToInput(); return;
      }

      /* Si el servidor devuelve un endpoint de transferencia real */
      const d = res.data || {};

      /* Mostrar info inicial */
      if (cmdVerb === 'cr.transferencia.enviar' || cmdVerb === 'cr.transferencia.enviar.carpeta') {
        addLine('  Enviando: ' + (params.origen || ''), 'term-line--dim');
      } else if (cmdVerb === 'cr.transferencia.recibir' || cmdVerb === 'cr.transferencia.recibir.carpeta') {
        addLine('  Recibiendo: ' + (params.origen || ''), 'term-line--dim');
      } else {
        /* otros subcomandos: mostrar resultado directo */
        Object.keys(d).forEach(function (k) {
          addLine('  ' + k + ': ' + (typeof d[k] === 'object' ? JSON.stringify(d[k]) : d[k]), '');
        });
        addBlank(); scrollToInput(); return;
      }

      const label = cmdVerb.indexOf('enviar') >= 0 ? 'Enviando objetos  ' : 'Recibiendo objetos';
      const prog  = createProgressLine(label);
      prog.update(0, 0, 0, 'activa');

      /* 2. Si hay endpoint directo (enviar), hacer el POST real del archivo */
      if (d.endpoint && d.headers && params.origen) {
        /* Fetch del archivo local — solo funciona si el navegador tiene acceso */
        /* En práctica el agente C hace este paso; desde el browser mostramos simulación */
        simulateProgress(prog, params);
        return;
      }

      /* 3. Si hay endpoint recv, iniciar la descarga y escuchar SSE */
      if (d.endpoint && d.endpoint.indexOf('/api/transfer/recv') >= 0) {
        /* Abrir SSE de progreso — el agente C descarga el archivo */
        /* Desde browser: iniciar descarga directa */
        const link = document.createElement('a');
        link.href     = d.endpoint;
        link.download = '';
        link.style.display = 'none';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        simulateProgress(prog, params);
        return;
      }

      /* Fallback: solo mostrar datos */
      prog.span.remove();
      Object.keys(d).forEach(function (k) {
        addLine('  ' + k + ': ' + (typeof d[k] === 'object' ? JSON.stringify(d[k]) : d[k]), '');
      });
      addBlank(); scrollToInput();
    })
    .catch(function (err) {
      addLine('  Sin conexion con el servidor: ' + err.message, 'term-line--err');
      addBlank(); scrollToInput();
    });
  }

  /* Simula progreso cuando el agente C es quien hace la transferencia real */
  function simulateProgress(prog, params) {
    /* Escuchar SSE si tenemos un transfer ID, o simular visualmente */
    var total = 0; /* desconocido desde el browser */
    var step  = 0;
    var steps = 30;
    var iv = setInterval(function () {
      step++;
      var pct = Math.min(Math.round((step / steps) * 100), 99);
      prog.update(pct, pct * 1024 * 50, steps * 1024 * 50, 'activa');
      scrollToInput();
      if (step >= steps) {
        clearInterval(iv);
        prog.update(100, steps * 1024 * 50, steps * 1024 * 50, 'completada');
        addBlank();
        scrollToInput();
      }
    }, 80);
  }

  /* ── HELP ───────────────────────────────────────────────────── */

  function showHelp() {
    if (!cmdData) {
      addLine('  Cargando comandos, intenta de nuevo en un momento.', 'term-line--err');
      return;
    }
    addLine('  Comandos disponibles de CoreRemote:', 'term-line--dim');
    addBlank();
    cmdData.grupos.forEach(function (grupo) {
      addLine('  \u2500\u2500 ' + grupo.titulo + ' \u2500\u2500', 'term-line--dim');
      grupo.comandos.forEach(function (c) {
        var cmd  = typeof c === 'string' ? c : c.cmd;
        var desc = typeof c === 'string' ? '' : c.desc;
        if (desc) {
          addLine('  ' + cmd, '');
          addLine('      \u2192 ' + desc, 'term-line--dim');
        } else {
          addLine('  ' + cmd, '');
        }
      });
      addBlank();
    });
  }

  /* ── RUN ────────────────────────────────────────────────────── */

  /* Parsea "key=value" o key="value con espacios" de la línea */
  function parseArgs(parts) {
    var obj = {};
    parts.forEach(function (p) {
      var eq = p.indexOf('=');
      if (eq < 0) return;
      var k = p.slice(0, eq).trim();
      var v = p.slice(eq + 1).trim().replace(/^"|"$/g, '');
      obj[k] = v;
    });
    return obj;
  }

  /* Envía un comando cr.* al endpoint /api/cmd del server.js */
  function runRemote(trimmed) {
    var parts  = trimmed.split(/\s+/);
    var verb   = parts[0];
    var params = parseArgs(parts.slice(1));
    params.cmd = verb;
    /* Incluir el agente seleccionado si está disponible */
    if (window.crGetSelectedAgent) {
      var aid = window.crGetSelectedAgent();
      if (aid) params._agentId = aid;
    }

    /* Spinner en la línea activa mientras espera */
    addLine('  ...', 'term-line--dim');
    scrollToInput();

    fetch('/api/cmd', {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify(params),
    })
    .then(function (r) { return r.json(); })
    .then(function (res) {
      /* Quitar la línea "..." */
      var dots = container.querySelector('.term-line--dim:last-of-type');
      if (dots && dots.textContent.trim() === '...') dots.remove();

      if (res.ok && res.data) {
        const d = res.data;

        /* Tabla especial para cr.proceso.lista */
        if (d.procesos && Array.isArray(d.procesos)) {
          if (d.total !== undefined) {
            addLine('  Total: ' + d.total + ' proceso(s)' + (d.aviso ? '  — ' + d.aviso : ''), 'term-line--dim');
          }
          addBlank();
          /* Cabecera */
          addLine('  ' +
            'PID'.padStart(7) + '  ' +
            'MEM (KB)'.padStart(10) + '  ' +
            'NOMBRE', 'term-line--dim');
          addLine('  ' + '-'.repeat(55), 'term-line--dim');
          d.procesos.forEach(function (p) {
            var nombre = typeof p === 'string' ? p : (p.nombre || '');
            var pid    = typeof p === 'object' ? String(p.pid    || '') : '';
            var mem    = typeof p === 'object' ? String(p.mem_kb || '') : '';
            addLine('  ' +
              pid.padStart(7) + '  ' +
              mem.padStart(10) + '  ' +
              nombre, '');
          });
        } else {
          /* Resto de campos */
          Object.keys(d).forEach(function (k) {
            var val = d[k];
            if (Array.isArray(val)) {
              addLine('  ' + k + ':', 'term-line--dim');
              val.forEach(function (item) {
                addLine('    ' + (typeof item === 'object' ? JSON.stringify(item) : item), '');
              });
            } else if (typeof val === 'object' && val !== null) {
              addLine('  ' + k + ': ' + JSON.stringify(val), '');
            } else {
              addLine('  ' + k + ': ' + val, '');
            }
          });
        }
      } else {
        addLine('  Error: ' + (res.error || 'respuesta inválida'), 'term-line--err');
      }
      addBlank();
      scrollToInput();
    })
    .catch(function (err) {
      addLine('  Sin conexión con el servidor: ' + err.message, 'term-line--err');
      addBlank();
      scrollToInput();
    });
  }

  function run(raw) {
    const trimmed = raw.trim();

    const row = document.createElement('span');
    row.className = 'term-line';
    const pre = document.createElement('span');
    pre.className = 'term-prompt-prefix';
    pre.textContent = 'xfx1: ';
    row.appendChild(pre);
    row.appendChild(document.createTextNode(trimmed));
    insertBefore(row);

    input.value = '';
    destroyAc();

    if (!trimmed) { addBlank(); scrollToInput(); return; }

    if (trimmed === 'clear') {
      [...container.children].forEach(function (el) { if (el !== activeLine) el.remove(); });
      scrollToInput();
      return;
    }

    const parts  = trimmed.split(/\s+/);
    const cmd    = parts[0].toLowerCase();
    const args   = parts.slice(1);
    const params = parseArgs(parts.slice(1));
    params.cmd   = cmd;

    if (cmd === 'cr.help' || cmd === 'ayuda') {
      showHelp();
      addBlank();
      scrollToInput();
    } else if (commands[cmd]) {
      const lines = commands[cmd](args);
      if (lines) lines.forEach(function (l) { addLine(l); });
      addBlank();
      scrollToInput();
    } else if (cmd.startsWith('cr.')) {
      /* Comandos remotos */
      if (cmd.startsWith('cr.transferencia.')) {
        /* Transferencia con barra de progreso */
        runTransfer(trimmed, params, cmd);
      } else {
        runRemote(trimmed);
      }
    } else {
      addLine('  xfx1: comando no encontrado: ' + cmd, 'term-line--err');
      addBlank();
      scrollToInput();
    }
  }

  /* ── EVENTOS TECLADO ────────────────────────────────────────── */

  input.addEventListener('input', function () {
    histIdx = -1;
    updateAc();
  });

  input.addEventListener('keydown', function (e) {
    /* Con dropdown abierto: navegar y seleccionar */
    if (acBox && acMatches.length > 0) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        acIdx = (acIdx + 1) % acMatches.length;
        renderAc();
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        acIdx = acIdx <= 0 ? acMatches.length - 1 : acIdx - 1;
        renderAc();
        return;
      }
      if (e.key === 'Tab' || (e.key === 'Enter' && acIdx >= 0)) {
        e.preventDefault();
        applyAc(acMatches[acIdx >= 0 ? acIdx : 0]);
        return;
      }
      if (e.key === 'Escape') {
        destroyAc();
        return;
      }
    }

    /* Sin dropdown: historial y ejecutar */
    if (e.key === 'Enter') {
      const val = input.value;
      if (val.trim()) { history.unshift(val); histIdx = -1; }
      run(val);
      return;
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (histIdx < history.length - 1) histIdx++;
      input.value = history[histIdx] || '';
      destroyAc();
      return;
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (histIdx > 0) histIdx--;
      else { histIdx = -1; input.value = ''; destroyAc(); return; }
      input.value = history[histIdx] || '';
      destroyAc();
    }
  });

  /* ── FOCO ───────────────────────────────────────────────────── */

  document.addEventListener('click', function (e) {
    if (window.getSelection && window.getSelection().toString().length > 0) return;
    if (!e.target.closest('a') && !e.target.closest('button') && !e.target.closest('#xfx1-ac')) {
      input.focus();
    }
  });

  document.getElementById('term-active-line').addEventListener('click', function () {
    if (window.getSelection && window.getSelection().toString().length > 0) return;
    input.focus();
  });

  input.addEventListener('blur', function () {
    /* Pequeño delay para que mousedown del dropdown se procese antes */
    setTimeout(function () {
      if (document.activeElement !== input) destroyAc();
    }, 150);
  });

  input.focus();
})();
