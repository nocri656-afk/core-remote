/*
 * nav.js — Dropdown de agentes conectados en /terminal
 *
 * - Muestra la lista de agentes registrados en server.js
 * - Permite seleccionar uno — todos los comandos van a ese agente
 * - Refresca la lista al abrir el dropdown y cada 10s automáticamente
 */
(function () {
  var btn      = document.getElementById('nav-agent-btn');
  var menu     = document.getElementById('nav-agent-menu');
  var checkBtn = document.getElementById('nav-check-btn');
  var dot      = document.getElementById('nai-dot');
  var text     = document.getElementById('nai-text');

  if (!btn || !menu) return;

  /* ID del agente actualmente seleccionado (null = default) */
  var selectedAgentId = null;

  /* Exponer globalmente para que engine.js lo use */
  window.crGetSelectedAgent = function () { return selectedAgentId; };

  /* ── Toggle dropdown ──────────────────────────────────────── */
  btn.addEventListener('click', function (e) {
    e.stopPropagation();
    var open = btn.getAttribute('aria-expanded') === 'true';
    btn.setAttribute('aria-expanded', String(!open));
    menu.hidden = open;
    if (!open) loadAgents();
  });

  document.addEventListener('click', function (e) {
    if (!btn.contains(e.target) && !menu.contains(e.target)) {
      btn.setAttribute('aria-expanded', 'false');
      menu.hidden = true;
    }
  });

  checkBtn.addEventListener('click', loadAgents);

  /* ── Cargar lista de agentes ──────────────────────────────── */
  function loadAgents() {
    text.textContent = '...';

    fetch('/api/agent/list')
      .then(function (r) { return r.json(); })
      .then(function (d) {
        renderAgents(d.agentes || []);
      })
      .catch(function () {
        renderAgents([]);
      });
  }

  function renderAgents(agentes) {
    /* Limpiar lista anterior */
    var existing = menu.querySelectorAll('.nai-agent-item');
    existing.forEach(function (el) { el.remove(); });

    var divider = menu.querySelector('.nav-agent-divider');

    if (agentes.length === 0) {
      text.textContent = 'no disponible';
      dot.className    = 'nai-dot offline';
      return;
    }

    /* Verificar si el seleccionado sigue en la lista */
    var ids = agentes.map(function (a) { return a.id; });
    if (selectedAgentId && ids.indexOf(selectedAgentId) < 0) {
      selectedAgentId = null;
    }
    if (!selectedAgentId) selectedAgentId = agentes[0].id;

    /* Mostrar estado del seleccionado en el nav */
    var sel = agentes.find(function (a) { return a.id === selectedAgentId; });
    if (sel) {
      dot.className    = sel.online ? 'nai-dot online' : 'nai-dot offline';
      text.textContent = sel.nombre;
    }

    /* Insertar items antes del divider */
    agentes.forEach(function (a) {
      var item = document.createElement('button');
      item.className   = 'nai-agent-item nav-agent-item';
      item.type        = 'button';
      item.dataset.id  = a.id;

      var indicator = document.createElement('span');
      indicator.className = 'nai-agent-indicator ' + (a.online ? 'online' : 'offline');

      var label = document.createElement('span');
      label.className   = 'nai-agent-name';
      label.textContent = a.nombre;

      var check = document.createElement('span');
      check.className   = 'nai-agent-check';
      check.textContent = a.id === selectedAgentId ? '✓' : '';

      item.appendChild(indicator);
      item.appendChild(label);
      item.appendChild(check);

      item.addEventListener('click', function () {
        selectedAgentId = a.id;
        btn.setAttribute('aria-expanded', 'false');
        menu.hidden = true;
        /* Actualizar nav */
        dot.className    = a.online ? 'nai-dot online' : 'nai-dot offline';
        text.textContent = a.nombre;
      });

      menu.insertBefore(item, divider);
    });
  }

  /* Refrescar cada 10s */
  setInterval(function () {
    if (!menu.hidden) loadAgents();   /* solo si el dropdown está abierto */
    else {
      /* Actualizar indicador del nav sin abrir el dropdown */
      fetch('/api/agent/list')
        .then(function (r) { return r.json(); })
        .then(function (d) {
          var agentes = d.agentes || [];
          if (agentes.length === 0) {
            dot.className    = 'nai-dot offline';
            text.textContent = 'no disponible';
            return;
          }
          if (!selectedAgentId) selectedAgentId = agentes[0].id;
          var sel = agentes.find(function (a) { return a.id === selectedAgentId; });
          if (sel) {
            dot.className    = sel.online ? 'nai-dot online' : 'nai-dot offline';
            text.textContent = sel.nombre;
          }
        })
        .catch(function () {});
    }
  }, 10000);

  /* Carga inicial */
  loadAgents();
})();
