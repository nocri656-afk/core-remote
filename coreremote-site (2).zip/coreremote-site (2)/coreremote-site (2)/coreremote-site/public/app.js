(() => {
  const connectButton = document.querySelector('#connect-button');
  const pinInput = document.querySelector('#client-pin');
  const passwordInput = document.querySelector('#agent-password');
  const message = document.querySelector('#form-message');

  if (!connectButton || !pinInput || !passwordInput || !message) return;

  connectButton.addEventListener('click', () => {
    message.hidden = false;

    if (!pinInput.value.trim()) {
      message.textContent = 'Escribe el PIN del equipo para continuar.';
      pinInput.focus();
      return;
    }

    if (!passwordInput.value) {
      message.textContent = 'Escribe la contraseña configurada en el agente.';
      passwordInput.focus();
      return;
    }

    passwordInput.value = '';
    message.textContent = 'El protocolo del agente aún debe integrarse. No se envió ni guardó tu contraseña.';
    passwordInput.focus();
  });
})();

// Acordeón de descargas
(() => {
  document.querySelectorAll('.dl-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const expanded = btn.getAttribute('aria-expanded') === 'true';
      const panel = document.getElementById(btn.getAttribute('aria-controls'));
      btn.setAttribute('aria-expanded', String(!expanded));
      panel.hidden = expanded;
    });
  });
})();

// ── Nav agente dropdown + agent bar ───────────────────────────
(() => {
  const btn        = document.getElementById('nav-agent-btn');
  const menu       = document.getElementById('nav-agent-menu');
  const winItem    = document.getElementById('nav-agent-windows');
  const agentBar   = document.getElementById('agent-bar');

  const statusView = document.getElementById('agent-status-view');
  const termView   = document.getElementById('agent-terminal-view');
  const statusDot  = document.getElementById('agent-status-dot');
  const statusLbl  = document.getElementById('agent-status-label');
  const openBtn    = document.getElementById('agent-open-terminal-btn');
  const backBtn    = document.getElementById('agent-back-btn');
  const miniTerm   = document.getElementById('agent-mini-term');
  const miniInput  = document.getElementById('agent-mini-input');

  if (!btn || !menu || !winItem || !agentBar) return;

  /* Toggle dropdown */
  btn.addEventListener('click', function (e) {
    e.stopPropagation();
    const open = btn.getAttribute('aria-expanded') === 'true';
    btn.setAttribute('aria-expanded', String(!open));
    menu.hidden = open;
  });

  /* Cerrar dropdown al hacer clic fuera */
  document.addEventListener('click', function (e) {
    if (!btn.contains(e.target) && !menu.contains(e.target)) {
      btn.setAttribute('aria-expanded', 'false');
      menu.hidden = true;
    }
  });

  /* Clic en "Windows" → mostrar agent bar con vista de estado */
  winItem.addEventListener('click', function () {
    btn.setAttribute('aria-expanded', 'false');
    menu.hidden = true;

    agentBar.hidden = false;
    showStatusView();
    checkAgent();
  });

  /* "Abrir terminal" → cambiar a vista terminal */
  openBtn.addEventListener('click', function () {
    showTerminalView();
    miniInput.focus();
  });

  /* Botón back → volver a vista estado */
  backBtn.addEventListener('click', function () {
    showStatusView();
  });

  function showStatusView() {
    statusView.hidden = false;
    termView.hidden   = true;
  }

  function showTerminalView() {
    statusView.hidden = true;
    termView.hidden   = false;
  }

  /* Verificar estado del agente */
  function checkAgent() {
    statusDot.className  = 'agent-status-dot';
    statusLbl.textContent = 'Verificando agente...';

    fetch('/api/status')
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (d.agent && d.agent.online) {
          statusDot.className   = 'agent-status-dot online';
          statusLbl.textContent = 'Agente conectado';
        } else {
          statusDot.className   = 'agent-status-dot offline';
          statusLbl.textContent = 'Agente no disponible — inicia xfx1.exe';
        }
      })
      .catch(function () {
        statusDot.className   = 'agent-status-dot offline';
        statusLbl.textContent = 'Sin conexión con el servidor';
      });
  }

  /* ── Mini terminal ──────────────────────────────────────────── */
  var termHistory = [];
  var termHistIdx = -1;

  function addMiniLine(text, cls) {
    var s = document.createElement('span');
    s.className = 'amt-line' + (cls ? ' ' + cls : '');
    s.textContent = text;
    miniTerm.appendChild(s);
    miniTerm.scrollTop = miniTerm.scrollHeight;
    return s;
  }

  function addMiniBlank() {
    var s = document.createElement('span');
    s.className = 'amt-blank';
    miniTerm.appendChild(s);
  }

  miniInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') {
      var val = miniInput.value.trim();
      miniInput.value = '';
      if (!val) return;

      /* Registrar en historial */
      termHistory.unshift(val);
      termHistIdx = -1;

      /* Imprimir prompt + comando */
      var row = document.createElement('span');
      row.className = 'amt-line';
      var pre = document.createElement('span');
      pre.className   = 'amt-prompt-prefix';
      pre.textContent = 'xfx1: ';
      row.appendChild(pre);
      row.appendChild(document.createTextNode(val));
      miniTerm.appendChild(row);
      miniTerm.scrollTop = miniTerm.scrollHeight;

      /* Ejecutar */
      if (val === 'clear') {
        miniTerm.innerHTML = '';
        return;
      }

      runMini(val);
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (termHistIdx < termHistory.length - 1) termHistIdx++;
      miniInput.value = termHistory[termHistIdx] || '';
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (termHistIdx > 0) { termHistIdx--; miniInput.value = termHistory[termHistIdx] || ''; }
      else { termHistIdx = -1; miniInput.value = ''; }
    }
  });

  function parseArgs(parts) {
    var obj = {};
    parts.forEach(function (p) {
      var eq = p.indexOf('=');
      if (eq < 0) return;
      var k = p.slice(0, eq).trim();
      var v = p.slice(eq + 1).trim().replace(/^"|"$/g, '');
      obj[k] = v;
    });
    return obj;
  }

  function runMini(raw) {
    var parts  = raw.split(/\s+/);
    var verb   = parts[0].toLowerCase();
    var params = parseArgs(parts.slice(1));
    params.cmd = verb;

    var loadLine = addMiniLine('  ...', 'amt-dim');

    fetch('/api/cmd', {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify(params),
    })
    .then(function (r) { return r.json(); })
    .then(function (res) {
      loadLine.remove();
      if (res.ok && res.data) {
        Object.keys(res.data).forEach(function (k) {
          var v = res.data[k];
          if (Array.isArray(v)) {
            addMiniLine('  ' + k + ':', 'amt-dim');
            v.slice(0, 20).forEach(function (item) {
              addMiniLine('    ' + (typeof item === 'object' ? JSON.stringify(item) : item), '');
            });
            if (v.length > 20) addMiniLine('    ... (' + (v.length - 20) + ' mas)', 'amt-dim');
          } else if (typeof v === 'object' && v !== null) {
            addMiniLine('  ' + k + ': ' + JSON.stringify(v), '');
          } else {
            addMiniLine('  ' + k + ': ' + v, '');
          }
        });
      } else {
        addMiniLine('  Error: ' + (res.error || 'respuesta invalida'), 'amt-err');
      }
      addMiniBlank();
      miniTerm.scrollTop = miniTerm.scrollHeight;
    })
    .catch(function (err) {
      loadLine.remove();
      addMiniLine('  Sin conexion: ' + err.message, 'amt-err');
      addMiniBlank();
    });
  }
})();
