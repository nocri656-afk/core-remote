(function () {
  const container  = document.getElementById('term-full');
  const activeLine = document.getElementById('term-active-line');
  const input      = document.getElementById('term-input');
  const history    = [];
  let histIdx      = -1;

  /* Carga commands.dat desde el servidor */
  let cmdData = null;
  fetch('/terminal/commands.dat')
    .then(function (r) { return r.json(); })
    .then(function (data) { cmdData = data; })
    .catch(function () { cmdData = null; });

  /* ── AUTOCOMPLETADO ─────────────────────────────────────────── */

  /* Construir lista plana de todos los comandos del dat */
  function getAllCommands() {
    if (!cmdData) return [];
    var list = [];
    cmdData.grupos.forEach(function (g) {
      g.comandos.forEach(function (c) {
        list.push(typeof c === 'string' ? c : c.cmd);
      });
    });
    return list;
  }

  /* Dropdown */
  var acBox      = null;   /* el <ul> flotante */
  var acMatches  = [];     /* sugerencias actuales */
  var acIdx      = -1;     /* item seleccionado (-1 = ninguno) */

  function createAcBox() {
    if (acBox) return;
    acBox = document.createElement('ul');
    acBox.id = 'xfx1-ac';
    acBox.setAttribute('role', 'listbox');
    acBox.style.cssText = [
      'position:absolute',
      'bottom:calc(100% + 4px)',
      'left:0',
      'min-width:320px',
      'max-width:600px',
      'max-height:220px',
      'overflow-y:auto',
      'background:#fff',
      'border:1px solid #d1d5db',
      'border-radius:6px',
      'box-shadow:0 4px 12px rgba(0,0,0,.12)',
      'list-style:none',
      'padding:4px 0',
      'margin:0',
      'z-index:100',
      'font-family:\'Courier New\',Courier,monospace',
      'font-size:14px',
    ].join(';');

    /* El wrap del input ya tiene position:relative desde cursor.js */
    var wrap = input.parentElement;
    wrap.style.position = 'relative';
    wrap.appendChild(acBox);
  }

  function destroyAc() {
    if (acBox) { acBox.remove(); acBox = null; }
    acMatches = [];
    acIdx     = -1;
  }

  function renderAc() {
    if (!acBox || acMatches.length === 0) { destroyAc(); return; }

    acBox.innerHTML = '';
    acMatches.forEach(function (cmd, i) {
      var li = document.createElement('li');
      li.setAttribute('role', 'option');
      li.setAttribute('aria-selected', i === acIdx ? 'true' : 'false');
      li.style.cssText = [
        'padding:4px 12px',
        'cursor:pointer',
        'white-space:nowrap',
        'overflow:hidden',
        'text-overflow:ellipsis',
        'color:#111',
        'background:' + (i === acIdx ? '#f3f4f6' : 'transparent'),
        'border-left:3px solid ' + (i === acIdx ? '#16a34a' : 'transparent'),
      ].join(';');

      /* Resaltar la parte que coincide */
      var typed = input.value;
      var idx   = cmd.toLowerCase().indexOf(typed.toLowerCase());
      if (idx >= 0 && typed.length > 0) {
        li.appendChild(document.createTextNode(cmd.slice(0, idx)));
        var mark = document.createElement('b');
        mark.style.color = '#16a34a';
        mark.textContent = cmd.slice(idx, idx + typed.length);
        li.appendChild(mark);
        li.appendChild(document.createTextNode(cmd.slice(idx + typed.length)));
      } else {
        li.textContent = cmd;
      }

      li.addEventListener('mousedown', function (e) {
        e.preventDefault(); /* no pierde el foco el input */
        applyAc(cmd);
      });
      li.addEventListener('mouseover', function () {
        acIdx = i;
        renderAc();
      });

      acBox.appendChild(li);
    });

    /* Scroll al item activo */
    if (acIdx >= 0) {
      var active = acBox.children[acIdx];
      if (active) active.scrollIntoView({ block: 'nearest' });
    }
  }

  function applyAc(cmd) {
    input.value = cmd;
    destroyAc();
    input.focus();
    /* Dispara actualización del cursor */
    input.dispatchEvent(new Event('input'));
  }

  function updateAc() {
    var val = input.value;
    if (!val || !cmdData) { destroyAc(); return; }

    var all     = getAllCommands();
    var lower   = val.toLowerCase();
    var matches = all.filter(function (c) {
      return c.toLowerCase().indexOf(lower) >= 0;
    });

    /* No mostrar si solo hay una coincidencia exacta */
    if (matches.length === 0 || (matches.length === 1 && matches[0] === val)) {
      destroyAc(); return;
    }

    acMatches = matches;
    acIdx     = -1;
    createAcBox();
    renderAc();
  }

  /* ── COMANDOS BUILT-IN ──────────────────────────────────────── */

  const commands = {
    clear()   { return null; },
    whoami()  { return ['xfx1-user']; },
    date()    { return [new Date().toLocaleString('es-ES')]; },
    version() { return ['xfx1 v1.0.0 — CoreRemote Terminal']; },
    echo(a)   { return [a.join(' ')]; },
  };

  /* ── HELPERS DOM ────────────────────────────────────────────── */

  function insertBefore(el) { container.insertBefore(el, activeLine); }

  function addLine(text, cls) {
    const s = document.createElement('span');
    s.className = 'term-line ' + (cls || '');
    s.textContent = text;
    insertBefore(s);
  }

  function addBlank() {
    const s = document.createElement('span');
    s.className = 'term-line term-line--blank';
    insertBefore(s);
  }

  function scrollToInput() {
    container.scrollTop = container.scrollHeight;
  }

  /* ── HELP ───────────────────────────────────────────────────── */

  function showHelp() {
    if (!cmdData) {
      addLine('  Cargando comandos, intenta de nuevo en un momento.', 'term-line--err');
      return;
    }
    addLine('  Comandos disponibles de CoreRemote:', 'term-line--dim');
    addBlank();
    cmdData.grupos.forEach(function (grupo) {
      addLine('  \u2500\u2500 ' + grupo.titulo + ' \u2500\u2500', 'term-line--dim');
      grupo.comandos.forEach(function (c) {
        var cmd  = typeof c === 'string' ? c : c.cmd;
        var desc = typeof c === 'string' ? '' : c.desc;
        if (desc) {
          addLine('  ' + cmd, '');
          addLine('      \u2192 ' + desc, 'term-line--dim');
        } else {
          addLine('  ' + cmd, '');
        }
      });
      addBlank();
    });
  }

  /* ── RUN ────────────────────────────────────────────────────── */

  function run(raw) {
    const trimmed = raw.trim();

    const row = document.createElement('span');
    row.className = 'term-line';
    const pre = document.createElement('span');
    pre.className = 'term-prompt-prefix';
    pre.textContent = 'xfx1: ';
    row.appendChild(pre);
    row.appendChild(document.createTextNode(trimmed));
    insertBefore(row);

    input.value = '';
    destroyAc();

    if (!trimmed) { addBlank(); scrollToInput(); return; }

    if (trimmed === 'clear') {
      [...container.children].forEach(function (el) { if (el !== activeLine) el.remove(); });
      scrollToInput();
      return;
    }

    const parts = trimmed.split(/\s+/);
    const cmd   = parts[0].toLowerCase();
    const args  = parts.slice(1);

    if (cmd === 'cr.help' || cmd === 'ayuda') {
      showHelp();
    } else if (commands[cmd]) {
      const lines = commands[cmd](args);
      if (lines) lines.forEach(function (l) { addLine(l); });
    } else {
      addLine('xfx1: comando no encontrado: ' + cmd, 'term-line--err');
    }

    addBlank();
    scrollToInput();
  }

  /* ── EVENTOS TECLADO ────────────────────────────────────────── */

  input.addEventListener('input', function () {
    histIdx = -1;
    updateAc();
  });

  input.addEventListener('keydown', function (e) {
    /* Con dropdown abierto: navegar y seleccionar */
    if (acBox && acMatches.length > 0) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        acIdx = (acIdx + 1) % acMatches.length;
        renderAc();
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        acIdx = acIdx <= 0 ? acMatches.length - 1 : acIdx - 1;
        renderAc();
        return;
      }
      if (e.key === 'Tab' || (e.key === 'Enter' && acIdx >= 0)) {
        e.preventDefault();
        applyAc(acMatches[acIdx >= 0 ? acIdx : 0]);
        return;
      }
      if (e.key === 'Escape') {
        destroyAc();
        return;
      }
    }

    /* Sin dropdown: historial y ejecutar */
    if (e.key === 'Enter') {
      const val = input.value;
      if (val.trim()) { history.unshift(val); histIdx = -1; }
      run(val);
      return;
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (histIdx < history.length - 1) histIdx++;
      input.value = history[histIdx] || '';
      destroyAc();
      return;
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (histIdx > 0) histIdx--;
      else { histIdx = -1; input.value = ''; destroyAc(); return; }
      input.value = history[histIdx] || '';
      destroyAc();
    }
  });

  /* ── FOCO ───────────────────────────────────────────────────── */

  document.addEventListener('click', function (e) {
    if (window.getSelection && window.getSelection().toString().length > 0) return;
    if (!e.target.closest('a') && !e.target.closest('button') && !e.target.closest('#xfx1-ac')) {
      input.focus();
    }
  });

  document.getElementById('term-active-line').addEventListener('click', function () {
    if (window.getSelection && window.getSelection().toString().length > 0) return;
    input.focus();
  });

  input.addEventListener('blur', function () {
    /* Pequeño delay para que mousedown del dropdown se procese antes */
    setTimeout(function () {
      if (document.activeElement !== input) destroyAc();
    }, 150);
  });

  input.focus();
})();
