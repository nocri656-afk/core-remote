/*
 * cr_agent.c — Loop principal del agente CoreRemote
 */

#include "cr_agent.h"
#include "cr_cmd.h"
#include "cr_net.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

/* ── Colores ANSI (desactivables si el terminal no los soporta) ─ */
#ifdef _WIN32
#  define COL_RESET  ""
#  define COL_GREEN  ""
#  define COL_CYAN   ""
#  define COL_RED    ""
#  define COL_DIM    ""
#  define COL_BOLD   ""
#else
#  define COL_RESET  "\033[0m"
#  define COL_GREEN  "\033[0;32m"
#  define COL_CYAN   "\033[0;36m"
#  define COL_RED    "\033[0;31m"
#  define COL_DIM    "\033[2m"
#  define COL_BOLD   "\033[1m"
#endif

/* ── Línea separadora ─────────────────────────────────────────── */
#define SEP "────────────────────────────────────────────────────────\n"

/* ═══════════════════════════════════════════════════════════════
 * cr_agent_init
 * ═══════════════════════════════════════════════════════════════ */
cr_result_t cr_agent_init(cr_session_t *sess,
                          const char   *host,
                          int           port)
{
    if (!sess) return CR_ERR_ARGS;
    memset(sess, 0, sizeof(*sess));

    strncpy(sess->host,
            host ? host : CR_SERVER_HOST,
            sizeof(sess->host) - 1);
    sess->port = port > 0 ? port : CR_SERVER_PORT;
    strncpy(sess->agent_version, CR_AGENT_VERSION, sizeof(sess->agent_version) - 1);
    strncpy(sess->cwd, ".", sizeof(sess->cwd) - 1);

    /* Generar ID de sesión simple: timestamp hexadecimal */
    snprintf(sess->session_id, sizeof(sess->session_id),
             "cr-%lx", (unsigned long)time(NULL));

    return CR_OK;
}

/* ═══════════════════════════════════════════════════════════════
 * cr_agent_ping
 * ═══════════════════════════════════════════════════════════════ */
cr_result_t cr_agent_ping(cr_session_t *sess)
{
    cr_response_t resp;
    cr_result_t r = cr_net_request(sess->host, sess->port,
                                   "/", NULL, &resp);
    if (r != CR_OK) {
        sess->connected = 0;
        return r;
    }
    sess->connected = (resp.status >= 200 && resp.status < 500) ? 1 : 0;
    return sess->connected ? CR_OK : CR_ERR_CONNECT;
}

/* ═══════════════════════════════════════════════════════════════
 * cr_agent_banner
 * ═══════════════════════════════════════════════════════════════ */
void cr_agent_banner(const cr_session_t *sess)

{
    printf("\n");
    printf(COL_GREEN COL_BOLD);
    printf("   ██████╗ ██████╗ ██████╗ ███████╗\n");
    printf("  ██╔════╝██╔═══██╗██╔══██╗██╔════╝\n");
    printf("  ██║     ██║   ██║██████╔╝█████╗  \n");
    printf("  ██║     ██║   ██║██╔══██╗██╔══╝  \n");
    printf("  ╚██████╗╚██████╔╝██║  ██║███████╗\n");
    printf("   ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝\n");
    printf(COL_RESET);

    printf(COL_CYAN COL_BOLD "  CORE REMOTE" COL_RESET
           COL_DIM " | Native Agent\n" COL_RESET);

    printf(COL_CYAN "  CoreRemote Agent v%s" COL_RESET "\n",
           sess->agent_version);

    printf(COL_DIM "  Conectado a %s:%d | sesión %s\n" COL_RESET,
           sess->host, sess->port, sess->session_id);

    printf(COL_DIM "  Escribe " COL_RESET
           COL_BOLD COL_GREEN "cr.help" COL_RESET
           COL_DIM " para ver los comandos disponibles.\n" COL_RESET);

    printf("\n");
}


/* ═══════════════════════════════════════════════════════════════
 * cr_agent_status
 * ═══════════════════════════════════════════════════════════════ */
void cr_agent_status(const cr_session_t *sess)
{
    printf(SEP);
    printf("  " COL_BOLD "Estado del agente CoreRemote\n" COL_RESET);
    printf(SEP);
    printf("  Versión    : %s\n", sess->agent_version);
    printf("  Servidor   : %s:%d\n", sess->host, sess->port);
    printf("  Sesión     : %s\n", sess->session_id);
    printf("  Conexión   : %s\n",
           sess->connected
               ? COL_GREEN "activa" COL_RESET
               : COL_RED   "inactiva" COL_RESET);
    printf("  Directorio : %s\n", sess->cwd[0] ? sess->cwd : ".");
    printf(SEP);
}

/* ═══════════════════════════════════════════════════════════════
 * cr_agent_help
 * ═══════════════════════════════════════════════════════════════ */
void cr_agent_help(void)
{
    printf(SEP);
    printf("  " COL_BOLD "Comandos internos del agente\n" COL_RESET);
    printf(SEP);
    printf("  %-28s %s\n", "cr.help",  "Lista todos los comandos CoreRemote");
    printf("  %-28s %s\n", "estado",   "Muestra el estado de la sesión");
    printf("  %-28s %s\n", "clear",    "Limpia la pantalla");
    printf("  %-28s %s\n", "salir",    "Cierra el agente");
    printf(SEP);
    printf("  Para comandos remotos escribe, por ejemplo:\n");
    printf("    cr.directorio.ver\n");
    printf("    cr.proceso.lista\n");
    printf("    cr.archivo.leer ruta=\"C:\\Temp\\log.txt\" lineas=50\n");
    printf(SEP);
}

/* ═══════════════════════════════════════════════════════════════
 * Helpers internos del loop
 * ═══════════════════════════════════════════════════════════════ */

/* Elimina espacios al inicio y al final de la cadena (in-place) */
static char *trim(char *s)
{
    while (isspace((unsigned char)*s)) s++;
    if (*s == '\0') return s;
    char *end = s + strlen(s) - 1;
    while (end > s && isspace((unsigned char)*end)) *end-- = '\0';
    return s;
}

/* Limpia la pantalla de forma portátil */
static void clear_screen(void)
{
#ifdef _WIN32
    system("cls");
#else
    printf("\033[H\033[2J");
    fflush(stdout);
#endif
}

/* Imprime el prompt del agente */
static void print_prompt(const cr_session_t *sess)
{
    printf(COL_GREEN COL_BOLD "cr[%s]" COL_RESET "> ",
           sess->connected ? "ok" : "!!");
    fflush(stdout);
}

/* ═══════════════════════════════════════════════════════════════
 * cr_agent_run — Loop principal
 * ═══════════════════════════════════════════════════════════════ */
cr_result_t cr_agent_run(cr_session_t *sess)
{
    char line[CR_MAX_CMD_LEN];

    /* Intentar ping inicial */
    printf(COL_DIM "  Verificando conexión con %s:%d...\n" COL_RESET,
           sess->host, sess->port);

    if (cr_agent_ping(sess) == CR_OK) {
        printf(COL_GREEN "  Servidor alcanzable.\n\n" COL_RESET);
    } else {
        printf(COL_RED
               "  AVISO: el servidor no responde. "
               "Asegúrate de que node server.js esté corriendo.\n"
               "  Los comandos quedarán en cola hasta que el servidor "
               "esté disponible.\n\n"
               COL_RESET);
    }

    cr_agent_banner(sess);

    while (1) {
        print_prompt(sess);

        if (!fgets(line, sizeof(line), stdin)) {
            /* EOF (Ctrl+D / Ctrl+Z) */
            printf("\n");
            break;
        }

        char *cmd_str = trim(line);
        if (cmd_str[0] == '\0') continue;   /* línea vacía */

        /* ── Comandos internos ─────────────────────────────── */
        if (strcmp(cmd_str, "salir") == 0 ||
            strcmp(cmd_str, "exit")  == 0 ||
            strcmp(cmd_str, "quit")  == 0) {
            printf(COL_DIM "  Cerrando agente CoreRemote...\n" COL_RESET);
            break;
        }

        if (strcmp(cmd_str, "clear") == 0 ||
            strcmp(cmd_str, "cls")   == 0) {
            clear_screen();
            continue;
        }

        if (strcmp(cmd_str, "estado") == 0 ||
            strcmp(cmd_str, "cr.sesion.estado") == 0) {
            /* Actualizar estado de conexión antes de mostrar */
            cr_agent_ping(sess);
            cr_agent_status(sess);
            continue;
        }

        if (strcmp(cmd_str, "cr.help") == 0 ||
            strcmp(cmd_str, "ayuda")   == 0) {
            cr_agent_help();
            continue;
        }

        /* ── Parsear y despachar al server.js ─────────────── */
        cr_cmd_t cmd;
        cr_result_t r = cr_cmd_parse(cmd_str, &cmd);

        if (r != CR_OK) {
            printf(COL_RED "  Error parseando comando: %d\n" COL_RESET, r);
            continue;
        }

        r = cr_cmd_dispatch(&cmd, sess);

        if (r == CR_ERR_CONNECT || r == CR_ERR_TIMEOUT) {
            /* Marcar sesión como desconectada y avisar */
            sess->connected = 0;
            printf(COL_RED
                   "  Sin conexión con el servidor. "
                   "Comprueba que node server.js esté activo.\n"
                   COL_RESET);
        } else if (r == CR_ERR_CMD_UNKNOWN) {
            printf(COL_RED
                   "  Comando no reconocido: %s\n"
                   "  Escribe cr.help para ver los comandos disponibles.\n"
                   COL_RESET, cmd.verb);
        } else if (r != CR_OK) {
            printf(COL_RED "  Error ejecutando comando: %d\n" COL_RESET, r);
        }
    }

    return CR_OK;
}
