/*
 * cr_agent.c -- Entry point del agente CoreRemote
 *
 * Modos de arranque:
 *   ./cr_agent               -> modo servidor TCP (escucha en 0.0.0.0:3002)
 *   ./cr_agent --interactive -> modo interactivo stdin (debug)
 *   ./cr_agent --host X --port Y -> personalizar host/puerto de server.js
 */

#include "cr_agent.h"
#include "cr_server.h"
#include "cr_cmd.h"
#include "cr_net.h"
#include "cr_transfer.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

/* Colores ANSI solo en no-Windows */
#ifdef _WIN32
#  define COL_RESET ""
#  define COL_GREEN ""
#  define COL_CYAN  ""
#  define COL_RED   ""
#  define COL_DIM   ""
#  define COL_BOLD  ""
#else
#  define COL_RESET "\033[0m"
#  define COL_GREEN "\033[0;32m"
#  define COL_CYAN  "\033[0;36m"
#  define COL_RED   "\033[0;31m"
#  define COL_DIM   "\033[2m"
#  define COL_BOLD  "\033[1m"
#endif

#define SEP "--------------------------------------------------------\n"

/* ---------------------------------------------------------------
 * cr_agent_init
 * --------------------------------------------------------------- */
cr_result_t cr_agent_init(cr_session_t *sess,
                          const char   *host,
                          int           port)
{
    if (!sess) return CR_ERR_ARGS;
    memset(sess, 0, sizeof(*sess));

    strncpy(sess->host,
            host ? host : CR_SERVER_HOST,
            sizeof(sess->host) - 1);
    sess->port = port > 0 ? port : CR_SERVER_PORT;
    strncpy(sess->agent_version, CR_AGENT_VERSION,
            sizeof(sess->agent_version) - 1);
    strncpy(sess->cwd, ".", sizeof(sess->cwd) - 1);

    snprintf(sess->session_id, sizeof(sess->session_id),
             "cr-%lx", (unsigned long)time(NULL));

    return CR_OK;
}

/* ---------------------------------------------------------------
 * cr_agent_ping  (comprueba que server.js responde)
 * --------------------------------------------------------------- */
cr_result_t cr_agent_ping(cr_session_t *sess)
{
    cr_response_t resp;
    cr_result_t r = cr_net_request(sess->host, sess->port,
                                   "/api/status", NULL, &resp);
    if (r != CR_OK) { sess->connected = 0; return r; }
    sess->connected = (resp.status >= 200 && resp.status < 500) ? 1 : 0;
    return sess->connected ? CR_OK : CR_ERR_CONNECT;
}

/* ---------------------------------------------------------------
 * Banner
 * --------------------------------------------------------------- */
static void print_banner(const cr_session_t *sess, int server_mode)
{
    printf("\n");
    printf("  +----------------------------------------------------+\n");
    printf("  |    ____                 ____                 _     |\n");
    printf("  |   / ___|___  _ __ ___  |  _ \\ ___ _ __ ___ | |_   |\n");
    printf("  |  | |   / _ \\| '__/ _ \\ | |_) / _ \\ '_ ` _ \\| __|  |\n");
    printf("  |  | |__| (_) | | |  __/ |  _ <  __/ | | | | | |_   |\n");
    printf("  |   \\____\\___/|_|  \\___| |_| \\_\\___|_| |_| |_|\\__|  |\n");
    printf("  |                                                    |\n");
    if (server_mode) {
    printf("  |  Native Agent v%-14s  [SERVER MODE]        |\n", sess->agent_version);
    } else {
    printf("  |  Native Agent v%-14s  [INTERACTIVE]        |\n", sess->agent_version);
    }
    printf("  +----------------------------------------------------+\n\n");
    printf("  Session : %s\n", sess->session_id);
    if (server_mode) {
    printf("  Listen  : 0.0.0.0:%d\n", CR_AGENT_LISTEN_PORT);
    printf("  server.js expected at %s:%d\n\n", sess->host, sess->port);
    } else {
    printf("  server.js : %s:%d\n", sess->host, sess->port);
    printf("  Type cr.help / estado / salir\n\n");
    }
}

/* ---------------------------------------------------------------
 * Modo interactivo (debug / testing sin browser)
 * --------------------------------------------------------------- */
static char *trim(char *s)
{
    while (isspace((unsigned char)*s)) s++;
    if (!*s) return s;
    char *e = s + strlen(s) - 1;
    while (e > s && isspace((unsigned char)*e)) *e-- = '\0';
    return s;
}

static void clear_screen(void)
{
#ifdef _WIN32
    system("cls");
#else
    printf("\033[H\033[2J");
    fflush(stdout);
#endif
}

void cr_agent_banner(const cr_session_t *sess)  { print_banner(sess, 0); }
void cr_agent_status(const cr_session_t *sess)
{
    printf(SEP);
    printf("  CoreRemote Agent -- Session Status\n");
    printf(SEP);
    printf("  Version   : %s\n",    sess->agent_version);
    printf("  Server    : %s:%d\n", sess->host, sess->port);
    printf("  Session   : %s\n",    sess->session_id);
    printf("  Connected : %s\n",    sess->connected ? "yes" : "no");
    printf("  Listen    : 0.0.0.0:%d\n", CR_AGENT_LISTEN_PORT);
    printf(SEP);
}

void cr_agent_help(void)
{
    printf(SEP);
    printf("  CoreRemote Agent -- Internal Commands\n");
    printf(SEP);
    printf("  %-30s %s\n", "cr.help",  "List all CoreRemote commands");
    printf("  %-30s %s\n", "estado",   "Show session status");
    printf("  %-30s %s\n", "clear",    "Clear the screen");
    printf("  %-30s %s\n", "salir",    "Quit the agent");
    printf(SEP);
}

cr_result_t cr_agent_run(cr_session_t *sess)
{
    char line[CR_MAX_CMD_LEN];
    print_banner(sess, 0);

    printf("  Checking server.js at %s:%d ...\n", sess->host, sess->port);
    if (cr_agent_ping(sess) == CR_OK)
        printf("  server.js reachable.\n\n");
    else
        printf("  WARNING: server.js not responding.\n\n");

    while (1) {
        printf("cr[%s]> ", sess->connected ? "ok" : "!!");
        fflush(stdout);

        if (!fgets(line, sizeof(line), stdin)) { printf("\n"); break; }
        char *s = trim(line);
        if (!*s) continue;

        if (!strcmp(s,"salir")||!strcmp(s,"exit")||!strcmp(s,"quit")) {
            printf("  Closing...\n"); break;
        }
        if (!strcmp(s,"clear")||!strcmp(s,"cls")) { clear_screen(); continue; }
        if (!strcmp(s,"estado")||!strcmp(s,"status")) {
            cr_agent_ping(sess); cr_agent_status(sess); continue;
        }
        if (!strcmp(s,"cr.help")||!strcmp(s,"ayuda")||!strcmp(s,"help")) {
            cr_agent_help(); continue;
        }

        /* Transferencias locales */
        cr_cmd_t cmd;
        if (cr_cmd_parse(s, &cmd) != CR_OK) {
            printf("  Parse error.\n"); continue;
        }

        if (!strcmp(cmd.verb,"cr.transferencia.enviar") ||
            !strcmp(cmd.verb,"cr.transferencia.enviar.carpeta")) {
            const char *o = cr_cmd_get(&cmd,"origen");
            const char *d = cr_cmd_get(&cmd,"destino");
            if (!o||!d) { printf("  Uso: cr.transferencia.enviar origen=\"...\" destino=\"...\"\n"); continue; }
            cr_transfer_send(sess, o, d);
            continue;
        }
        if (!strcmp(cmd.verb,"cr.transferencia.recibir") ||
            !strcmp(cmd.verb,"cr.transferencia.recibir.carpeta")) {
            const char *o = cr_cmd_get(&cmd,"origen");
            const char *d = cr_cmd_get(&cmd,"destino");
            if (!o||!d) { printf("  Uso: cr.transferencia.recibir origen=\"...\" destino=\"...\"\n"); continue; }
            cr_transfer_recv(sess, o, d);
            continue;
        }

        /* Resto: despachar a server.js */
        cr_result_t r = cr_cmd_dispatch(&cmd, sess);
        if (r == CR_ERR_CONNECT || r == CR_ERR_TIMEOUT) {
            sess->connected = 0;
            printf("  No connection to server.js\n");
        } else if (r == CR_ERR_CMD_UNKNOWN) {
            printf("  Unknown command: %s\n", cmd.verb);
        } else if (r != CR_OK) {
            printf("  Error: %d\n", r);
        }
    }
    return CR_OK;
}
